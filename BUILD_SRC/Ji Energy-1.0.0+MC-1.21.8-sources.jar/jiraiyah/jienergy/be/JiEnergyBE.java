/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jienergy.be;

import jiraiyah.jibase.constants.BEKeys;
import jiraiyah.jibase.enumerations.MappedDirection;
import jiraiyah.jibase.records.BlockPosPayload;
import jiraiyah.jienergy.base.EnergyConnector;
import jiraiyah.jienergy.interfaces.IEnergyConnector;
import jiraiyah.jiralib.blockentity.JiScreenBE;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3222;
import team.reborn.energy.api.EnergyStorage;

@SuppressWarnings("UnusedReturnValue")
public abstract class JiEnergyBE <T extends JiEnergyBE<T, B>, B extends EnergyStorage> extends JiScreenBE<T, BlockPosPayload>
        implements IEnergyConnector<B>
{
    protected final EnergyConnector<B> energyStorage;

    public JiEnergyBE(class_2591<T> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
        energyStorage = new EnergyConnector<>();
    }

    @Override
    public BlockPosPayload getScreenOpeningData(class_3222 player)
    {
        return new BlockPosPayload(this.field_11867);
    }

    @Override
    public EnergyConnector<B> getEnergyConnector()
    {
        return this.energyStorage;
    }

    @Override
    protected void method_11014(class_11368 view)
    {
        super.method_11014(view);
        energyStorage.readData(view);
    }

    @Override
    protected void method_11007(class_11372 view)
    {
        super.method_11007(view);
        energyStorage.writeData(view);
    }

    @SuppressWarnings("unchecked")
    public B getEnergyStorage(class_2350 direction)
    {
        if(field_11863 == null)
            return null;
        if(field_11863.method_8320(field_11867).method_28501().contains(class_2741.field_12525))
            return this.energyStorage.getStorageProvider(direction, field_11863.method_8320(field_11867).method_11654(class_2741.field_12525));
        return (B) this.energyStorage.getStorage(direction);
    }

    public B getEnergyStorage(MappedDirection direction)
    {
        return getEnergyStorage(MappedDirection.toDirection(direction));
    }
}