/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jienergy.utils;

import jiraiyah.jiralib.blockentity.JiBlockEntity;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import team.reborn.energy.api.EnergyStorage;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class EnergyHelper
{
    public static long simulateInsertion(EnergyStorage storage, Transaction outer)
    {
        long amount = 0;
        try(Transaction transaction = outer.openNested())
        {
            amount = storage.insert(Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static long simulateInsertion(EnergyStorage storage)
    {
        long amount = 0;
        try(Transaction transaction = Transaction.openOuter())
        {
            amount = storage.insert(Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static long simulateExtraction(EnergyStorage storage, Transaction outer)
    {
        long amount = 0;
        try(Transaction transaction = outer.openNested())
        {
            amount = storage.extract(Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static long simulateExtraction(EnergyStorage storage)
    {
        long amount = 0;
        try(Transaction transaction = Transaction.openOuter())
        {
            amount = storage.extract(Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static boolean isEmpty(EnergyStorage storage)
    {
        return storage.getAmount() == 0;
    }

    public static boolean isStorageFull(EnergyStorage storage)
    {
        return storage.getAmount() >= storage.getCapacity();
    }

    public static boolean canAccept(EnergyStorage storage, int amount)
    {
        return storage.getAmount() + amount <= storage.getCapacity();
    }

    public static EnergyStorage getStorage(class_1937 world, class_2338 pos, class_2350 direction, Set<class_2338> blacklist)
    {
        class_2338 adjacentPos = pos.method_10093(direction);
        if(blacklist != null && blacklist.contains(adjacentPos))
            return null;
        return EnergyStorage.SIDED.find(world, pos, direction.method_10153());
    }

    public static List<EnergyStorage> getAllStorages(class_1937 world, class_2338 pos, Set<class_2338> blacklist)
    {
        List<EnergyStorage> storages = new ArrayList<>();
        for (class_2350 direction : class_2350.values())
        {
            class_2338 adjacentPos = pos.method_10093(direction);
            if(blacklist != null && blacklist.contains(adjacentPos))
                return null;
            EnergyStorage storage = EnergyStorage.SIDED.find(world, pos, direction.method_10153());

            if(storage != null)
                storages.add(storage);
        }
        return storages;
    }

    public void spread(class_2586 blockEntity, EnergyStorage storage, boolean equalAmount, Set<class_2338> blacklist)
    {
        List<EnergyStorage> storages = getAllStorages(blockEntity.method_10997(), blockEntity.method_11016(), blacklist);

        if(storages.isEmpty())
            return;

        try(Transaction transaction = Transaction.openOuter())
        {
            long current = storage.getAmount();
            long extractable = simulateExtraction(storage);
            long totalInserted = 0;
            long finalAmount = equalAmount ? extractable / storages.size() : extractable;

            for (EnergyStorage adjacentStorage : storages)
            {
                long inserted = adjacentStorage.insert(finalAmount, transaction);
                totalInserted += inserted;
            }

            if(totalInserted > 0)
            {
                try(Transaction inner = transaction.openNested())
                {
                    storage.extract(totalInserted, inner);
                    transaction.commit();
                }
            }

            if(current != storage.getAmount())
            {
                if (blockEntity instanceof JiBlockEntity<?> be)
                    be.update();
                else
                    blockEntity.method_5431();
            }
        }
    }

    public void spread(class_2586 blockEntity, EnergyStorage storage, Set<class_2338> blacklist)
    {
        spread(blockEntity, storage, true, blacklist);
    }

    public void spread(class_2586 blockEntity, EnergyStorage storage, boolean equalAmount)
    {
        spread(blockEntity, storage, equalAmount, null);
    }

    public void spread(class_2586 blockEntity, EnergyStorage storage)
    {
        spread(blockEntity, storage, true, null);
    }
}