/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jienergy.base;

import jiraiyah.jibase.constants.BEKeys;
import jiraiyah.jibase.enumerations.MappedDirection;
import jiraiyah.jibase.interfaces.IStorageConnector;
import jiraiyah.jibase.interfaces.IStorageProvider;
import jiraiyah.jibase.utils.PosHelper;
import jiraiyah.jiralib.util.StorageConnector;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2350;
import org.jetbrains.annotations.Nullable;
import team.reborn.energy.api.EnergyStorage;
import team.reborn.energy.api.base.SimpleEnergyStorage;

import java.util.Iterator;

public class EnergyConnector<T extends EnergyStorage> extends StorageConnector<EnergyStorage>
        implements IStorageConnector<EnergyConnector<T>>, IStorageProvider<T>
{
    @Override
    public EnergyConnector<T> getConnector()
    {
        return this;
    }

    @SuppressWarnings("unchecked")
    @Override
    public @Nullable T getStorageProvider(MappedDirection direction, class_2350 facing)
    {
        class_2350 side = PosHelper.relativeDirection(MappedDirection.toDirection(direction), facing);
        if(this.getSidedMap().containsKey(MappedDirection.fromDirection(side)))
            return (T) getStorage(side);
        return null;
    }

    @SuppressWarnings("unchecked")
    public T getStorageProvider(class_2350 direction, class_2350 facing)
    {
        class_2350 side = PosHelper.relativeDirection(direction, facing);
        if(this.getSidedMap().containsKey(MappedDirection.fromDirection(side)))
            return (T) getStorage(side);
        return null;
    }

    public long getAmount(MappedDirection direction)
    {
        return getStorage(direction).getAmount();
    }

    public long getAmount(class_2350 direction)
    {
        return getStorage(direction).getAmount();
    }

    public long getAmount(int index)
    {
        return getStorage(index).getAmount();
    }

    public long getCapacity(MappedDirection direction)
    {
        return getStorage(direction).getCapacity();
    }

    public long getCapacity(class_2350 direction)
    {
        return getStorage(direction).getCapacity();
    }

    public long getCapacity(int index)
    {
        return getStorage(index).getCapacity();
    }

    @Override
    public void writeData(class_11372 writeView)
    {
        class_11372.class_11374 list = writeView.method_71476("energy" + BEKeys.HAS_ENERGY);
        for(EnergyStorage storage : storages)
        {
            class_11372 energyView = list.method_71480();
            energyView.method_71466("Amount", storage.getAmount());
        }
    }

    @Override
    public void readData(class_11368 readView)
    {
        int index = 0;
        for (class_11368 view : readView.method_71438("energy" + BEKeys.HAS_ENERGY))
        {
            if(index >= storages.size())
                break;

            EnergyStorage storage = this.storages.get(index);

            if(storage instanceof SimpleEnergyStorage simpleEnergyStorage)
                simpleEnergyStorage.amount = view.method_71425("Amount", 0L);
            else
            {
                try(Transaction transaction = Transaction.openOuter())
                {
                    long amount = view.method_71425("Amount", 0L);
                    long current = storage.getAmount();
                    if(current < amount)
                        storage.insert(amount - current, transaction);
                    else
                        storage.extract(current - amount, transaction);
                    transaction.commit();
                }
            }

            index++;
        }
    }
}