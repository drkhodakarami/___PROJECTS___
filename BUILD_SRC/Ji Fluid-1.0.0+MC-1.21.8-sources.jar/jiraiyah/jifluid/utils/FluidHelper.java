/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jifluid.utils;

import jiraiyah.jibase.enumerations.MappedDirection;
import jiraiyah.jibase.records.FluidStackPayload;
import jiraiyah.jiralib.blockentity.JiBlockEntity;
import net.fabricmc.fabric.api.transfer.v1.context.ContainerItemContext;
import net.fabricmc.fabric.api.transfer.v1.fluid.*;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.SingleFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.StorageView;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleVariantStorage;
import net.fabricmc.fabric.api.transfer.v1.transaction.Transaction;
import net.minecraft.class_1263;
import net.minecraft.class_1268;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1802;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import net.minecraft.class_3414;
import net.minecraft.class_3419;
import org.jetbrains.annotations.Nullable;

import java.util.ArrayList;
import java.util.List;
import java.util.Set;

public class FluidHelper
{
    public static boolean isEmpty(SingleFluidStorage storage)
    {
        return storage.getAmount() == 0;
    }

    public static boolean isEmpty(SingleVariantStorage<FluidVariant> storage)
    {
        return storage.getAmount() == 0;
    }

    public static boolean isEmpty(Storage<FluidVariant> storage)
    {
        for (StorageView<FluidVariant> view : storage)
            if (view.getAmount() > 0)
                return false;

        return true;
    }

    public static boolean handleStorageTransfer(class_1937 world, class_2338 pos, SingleFluidStorage storage,
                                                class_1263 inputInventory,
                                                int inputSlot,
                                                boolean fullTransfer)
    {
        if(transferToStorage(world, pos, storage, inputInventory, inputSlot, fullTransfer))
            return true;
        return transferFromStorage(world, pos, storage, inputInventory, inputSlot, fullTransfer);
    }

    public static boolean handleStorageTransfer(class_1937 world, class_2338 pos, SingleVariantStorage<FluidVariant> storage,
                                                class_1263 inputInventory,
                                                int inputSlot,
                                                boolean fullTransfer)
    {
        if(transferToStorage(world, pos, storage, inputInventory, inputSlot, fullTransfer))
            return true;
        return transferFromStorage(world, pos, storage, inputInventory, inputSlot, fullTransfer);
    }

    public static boolean handleStorageTransfer(class_1937 world, class_2338 pos, Storage<FluidVariant> storage,
                                                class_1263 inputInventory,
                                                int inputSlot,
                                                boolean fullTransfer)
    {
        if(transferToStorage(world, pos, storage, inputInventory, inputSlot, fullTransfer))
            return true;
        return transferFromStorage(world, pos, storage, inputInventory, inputSlot, fullTransfer);
    }

    private static boolean transferFromStorage(class_1937 world, class_2338 pos, Storage<FluidVariant> storage, class_1263 inputInventory, int inputSlot, boolean fullTransfer)
    {
        Storage<FluidVariant> slotStorage = ContainerItemContext.withConstant(inputInventory.method_5438(inputSlot)).find(FluidStorage.ITEM);

        if (slotStorage == null)
            return false;

        for(StorageView<FluidVariant> storageView : storage)
        {
            FluidVariant variant = storageView.getResource();

            if (storageView.isResourceBlank() || storageView.getAmount() == 0)
                continue;

            for (StorageView<FluidVariant> view : slotStorage)
            {
                try (Transaction transaction = Transaction.openOuter())
                {
                    long storageTransfer = slotStorage.insert(variant, Long.MAX_VALUE, transaction);
                    long extracted = storage.extract(variant, storageTransfer, transaction);


                    if (storageTransfer == 0)
                        continue;

                    if (storageTransfer > 0)
                    {
                        if (fullTransfer && storageTransfer != extracted)
                            continue;

                        transaction.commit();
                        class_3414 sound = FluidVariantAttributes.getFillSound(variant);
                        world.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
                        return true;
                    }
                }
            }
        }

        return false;
    }

    private static boolean transferToStorage(class_1937 world, class_2338 pos, Storage<FluidVariant> storage, class_1263 inputInventory, int inputSlot, boolean fullTransfer)
    {
        Storage<FluidVariant> slotStorage = ContainerItemContext.withConstant(inputInventory.method_5438(inputSlot)).find(FluidStorage.ITEM);

        if(slotStorage == null)
            return false;

        for (StorageView<FluidVariant> view : slotStorage)
        {
            if(view.isResourceBlank() || view.getAmount() == 0)
                continue;

            FluidVariant variant = view.getResource();

            try(Transaction transaction = Transaction.openOuter())
            {
                long extracted = slotStorage.extract(variant, Long.MAX_VALUE, transaction);
                long storageTransfer = storage.insert(variant, extracted, transaction);

                if(storageTransfer == 0)
                    continue;

                if(storageTransfer > 0)
                {
                    if(fullTransfer && storageTransfer != extracted)
                        continue;

                    if(storageTransfer < extracted)
                        slotStorage.insert(variant, extracted - storageTransfer, transaction);

                    transaction.commit();
                    class_3414 sound = FluidVariantAttributes.getEmptySound(variant);
                    world.method_8396(null, pos, sound, class_3419.field_15245, 1.0F, 1.0F);
                    return true;
                }
            }
        }

        return false;
    }


    public static boolean interactWithBlock(class_1937 world, class_2338 pos, class_1657 player, class_1268 hand)
    {
        Storage<FluidVariant> storage;
        for (MappedDirection direction : MappedDirection.values())
        {
            storage = FluidStorage.SIDED.find(world, pos, MappedDirection.toDirection(direction));

            if(storage != null)
                if(FluidStorageUtil.interactWithFluidStorage(storage, player, hand))
                    return true;
        }

        return false;
    }

    public static boolean isValidSlot(class_1263 inventory, int slot, class_1799 itemStack)
    {
        // EMPTY BUCKET
        class_1799 slotStack = inventory.method_5438(slot);

        if(itemStack.method_7960())
            return false;

        if(slotStack.method_7960())
            return true;

        if(!slotStack.method_31574(itemStack.method_7909()))
            return false;

        if(slotStack.method_7947() + itemStack.method_7947() > slotStack.method_7914())
            return false;

        Storage<FluidVariant> itemStorage = ContainerItemContext.withConstant(itemStack).find(FluidStorage.ITEM);
        Storage<FluidVariant> slotStorage = ContainerItemContext.withConstant(slotStack).find(FluidStorage.ITEM);

        boolean variantFlag = false;
        boolean itemFlag = false;

        if(itemStorage == null || slotStorage == null)
            return false;

        for(StorageView<FluidVariant> slotView : slotStorage)
        {
            if(slotView.isResourceBlank())
                continue;
            for(StorageView<FluidVariant> itemView : itemStorage)
            {
                if(itemView.isResourceBlank())
                    continue;

                if(slotView.getResource() == itemView.getResource())
                    variantFlag = true;

                if(slotView.getAmount() == itemView.getAmount())
                    itemFlag = true;
            }
        }
        return variantFlag && itemFlag;
    }

    public static boolean isEmptyBucket(class_1263 inventory, int slot)
    {
        return inventory.method_5438(slot).method_31574(class_1802.field_8550);
    }

    public static long simulateInsertion(Storage<FluidVariant> storage, FluidVariant variant, Transaction outer)
    {
        long amount = 0;
        try(Transaction transaction = outer.openNested())
        {
            amount = storage.insert(variant, Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static long simulateInsertion(Storage<FluidVariant> storage, FluidVariant variant)
    {
        long amount = 0;
        try(Transaction transaction = Transaction.openOuter())
        {
            amount = storage.insert(variant, Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static long simulateExtraction(Storage<FluidVariant> storage, FluidVariant variant, Transaction outer)
    {
        long amount = 0;
        try(Transaction transaction = outer.openNested())
        {
            amount = storage.extract(variant, Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static long simulateExtraction(Storage<FluidVariant> storage, FluidVariant variant)
    {
        long amount = 0;
        try(Transaction transaction = Transaction.openOuter())
        {
            amount = storage.extract(variant, Long.MAX_VALUE, transaction);
            transaction.abort();
        }
        return amount;
    }

    public static boolean sameFluidInStorage(class_1263 inventory, int slot, Storage<FluidVariant> storage)
    {
        class_1799 slotStack = inventory.method_5438(slot);

        if(slotStack.method_7960())
            return false;

        Storage<FluidVariant> slotStorage = ContainerItemContext.withConstant(slotStack).find(FluidStorage.ITEM);

        return sameFluidInStorage(slotStorage, storage);
    }

    public static boolean sameFluidInStorage(Storage<FluidVariant> storage1, Storage<FluidVariant> storage2)
    {
        if(storage1 == null || storage2 == null)
            return false;

        for(StorageView<FluidVariant> slotView : storage1)
        {
            if (slotView.isResourceBlank())
                continue;
            boolean found = false;
            for (StorageView<FluidVariant> storageView : storage2)
            {
                if (storageView.isResourceBlank())
                    continue;

                if(slotView.getResource() == storageView.getResource())
                    found = true;
            }
            if(!found)
                return false;
        }

        return true;
    }

    public static boolean isStorageFull(Storage<FluidVariant> storage)
    {
        if(storage == null)
            return true;

        for(StorageView<FluidVariant> slotView : storage)
        {
            if (slotView.isResourceBlank())
                return false;

            if(slotView.getAmount() < slotView.getCapacity())
                return false;
        }

        return true;
    }

    public static boolean canAccept(FluidStackPayload stack, Storage<FluidVariant> storage)
    {
        if(storage == null)
            return false;

        try(Transaction transaction = Transaction.openOuter())
        {
            long amount = storage.insert(stack.fluid(), Long.MAX_VALUE, transaction);
            return stack.amount() <= amount && amount > 0;
        }
    }

    public static Storage<FluidVariant> getStorage(class_1937 world, class_2338 pos, class_2350 direction, Set<class_2338> blacklist)
    {
        class_2338 adjacentPos = pos.method_10093(direction);
        if(blacklist != null && blacklist.contains(adjacentPos))
            return null;

        return FluidStorage.SIDED.find(world, adjacentPos, direction.method_10153());
    }

    public static List<Storage<FluidVariant>> getAllStorages(class_1937 world, class_2338 pos, Set<class_2338> blacklist)
    {
        List<Storage<FluidVariant>> storages = new ArrayList<>();
        for (class_2350 direction : class_2350.values())
        {
            class_2338 adjacentPos = pos.method_10093(direction);
            if(blacklist != null && blacklist.contains(adjacentPos))
                continue;

            Storage<FluidVariant> storage = FluidStorage.SIDED.find(world, adjacentPos, direction.method_10153());

            if(storage != null)
                storages.add(storage);
        }

        return storages;
    }

    public void spread(class_2586 blockEntity, Storage<FluidVariant> storage, boolean equalAmount,Set<class_2338> blacklist)
    {
        class_2338 adjacentPos;

        List<Storage<FluidVariant>> adjacentStorages = getAllStorages(blockEntity.method_10997(), blockEntity.method_11016(), blacklist);

        if(adjacentStorages.isEmpty())
            return;

        for (StorageView<FluidVariant> storageView : storage)
        {
            FluidVariant variant = storageView.getResource();
            long currentAmount = storageView.getAmount();
            long totalInserted = 0;
            long totalExtractable = simulateExtraction(storage, variant);

            long finalAmount = equalAmount ? totalExtractable / adjacentStorages.size() : totalExtractable;

            for(Storage<FluidVariant> adjacentStorage : adjacentStorages)
            {
                try(Transaction transaction = Transaction.openOuter())
                {
                    long inserted = adjacentStorage.insert(variant, finalAmount, transaction);
                    if(inserted == finalAmount)
                    {
                        transaction.commit();
                        totalInserted += inserted;
                    }
                    else
                        transaction.abort();
                }
            }

            if(totalInserted > 0)
            {
                try(Transaction transaction = Transaction.openOuter())
                {
                    storage.extract(variant, totalInserted, transaction);
                    transaction.commit();
                }
            }

            if(currentAmount != storageView.getAmount())
            {
                if (blockEntity instanceof JiBlockEntity<?> be)
                    be.update();
                else
                    blockEntity.method_5431();
            }
        }
    }

    public void spread(class_2586 blockEntity, Storage<FluidVariant> storage,Set<class_2338> blacklist)
    {
        spread(blockEntity, storage, true, blacklist);
    }

    public void spread(class_2586 blockEntity, Storage<FluidVariant> storage, boolean equalAmount)
    {
        spread(blockEntity, storage, equalAmount, null);
    }

    public void spread(class_2586 blockEntity, Storage<FluidVariant> storage)
    {
        spread(blockEntity, storage, true, null);
    }
}