/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jifluid.base;

import com.mojang.datafixers.util.Pair;
import com.mojang.serialization.DataResult;
import jiraiyah.jibase.constants.BEKeys;
import jiraiyah.jibase.enumerations.MappedDirection;
import jiraiyah.jibase.interfaces.IStorageConnector;
import jiraiyah.jibase.interfaces.IStorageProvider;
import jiraiyah.jibase.records.FluidStackPayload;
import jiraiyah.jibase.utils.PosHelper;
import jiraiyah.jiralib.util.StorageConnector;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidVariant;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.SingleFluidStorage;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.Storage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedStorage;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;
import java.util.function.BiFunction;

public class FluidConnector<T extends SingleFluidStorage> extends StorageConnector<T>
        implements IStorageConnector<FluidConnector<T>>, IStorageProvider<T>
{
    private final CombinedStorage<FluidVariant, T> combinedStorage = new CombinedStorage<>(this.storages);

    public CombinedStorage<FluidVariant, T> getCombinedStorage()
    {
        return combinedStorage;
    }

    public List<FluidStackPayload> getFluids()
    {
        List<FluidStackPayload> fluids = new ArrayList<>();
        this.storages.forEach(storage -> {
            storage.nonEmptyViews().forEach(fluidContainer -> {
                fluids.add(new FluidStackPayload(fluidContainer.getResource(), fluidContainer.getAmount()));
            });
        });
        return fluids;
    }

    public void addStorage(class_2586 blockEntity, int size, BiFunction<class_2586, Integer, T> factory)
    {
        addStorage(factory.apply(blockEntity, size));
    }

    public void addStorage(class_2586 blockEntity, int size, MappedDirection side, BiFunction<class_2586, Integer, T> factory)
    {
        addStorage(factory.apply(blockEntity, size), side);
    }

    public void addStorage(class_2586 blockEntity, int size, class_2350 side, BiFunction<class_2586, Integer, T> factory)
    {
        addStorage(factory.apply(blockEntity, size), side);
    }

    public long getAmount(MappedDirection direction)
    {
        return getStorage(direction).getAmount();
    }

    public long getCapacity(MappedDirection direction)
    {
        return getStorage(direction).getCapacity();
    }

    public FluidVariant getVariant(MappedDirection direction)
    {
        return getStorage(direction).getResource();
    }

    public long getAmount(int index)
    {
        return getStorage(index).getAmount();
    }

    public long getCapacity(int index)
    {
        return getStorage(index).getCapacity();
    }

    public FluidVariant getVariant(int index)
    {
        return getStorage(index).getResource();
    }

    @Override
    public FluidConnector<T> getConnector()
    {
        return this;
    }

    @Override
    public T getStorageProvider(MappedDirection direction, class_2350 facing)
    {

        class_2350 side = PosHelper.relativeDirection(MappedDirection.toDirection(direction), facing);
        if(this.getSidedMap().containsKey(MappedDirection.fromDirection(side)))
            return getStorage(side);
        return null;
    }

    @Override
    public T getStorageProvider(class_2350 direction, class_2350 facing)
    {
        class_2350 side = PosHelper.relativeDirection(direction, facing);
        if(this.getSidedMap().containsKey(MappedDirection.fromDirection(side)))
            return getStorage(side);
        return null;
    }

    @Override
    public void writeData(class_11372 writeView)
    {
        class_11372.class_11374 list = writeView.method_71476("fluid" + BEKeys.HAS_FLUID);
        for (T storage : storages)
        {
            if(storage instanceof SingleFluidStorage singleFluidStorage)
            {
                /*WriteView fluidView = list.add();
                fluidView.putLong("Amount", singleFluidStorage.getAmount());
                DataResult<NbtElement> encoded = FluidVariant.CODEC.encode(singleFluidStorage.getResource(), NbtOps.INSTANCE, new NbtCompound());

                if(encoded.result().isPresent())
                {
                    NbtElement element = encoded.result().get();

                    if(element instanceof NbtCompound compound)
                        fluidView.put("fluid", NbtCompound.CODEC, compound);
                    else
                        throw new IllegalArgumentException("Encoded Fluid Variant is not an NbtCompound");
                }
                else
                    throw new IllegalArgumentException("Fluid Variant encoding failed : " + encoded.error());*/

                class_11372 compoundView = list.method_71480();
                singleFluidStorage.writeData(compoundView);
            }
        }
    }

    @Override
    public void readData(class_11368 readView)
    {
        int index = 0;
        for (class_11368 view : readView.method_71438("fluid" + BEKeys.HAS_FLUID))
        {
            if(index >= storages.size())
                break;

            T storage = this.storages.get(index);

            if(storage instanceof SingleFluidStorage singleFluidStorage)
            {
                /*singleFluidStorage.amount = view.getLong("Amount", 0L);

                Optional<NbtCompound> optionalVariantCompound = view.read("Fluid", NbtCompound.CODEC);

                optionalVariantCompound.ifPresent(nbt ->
                                                          singleFluidStorage.variant =
                                                                  FluidVariant.CODEC.decode(NbtOps.INSTANCE, nbt)
                                                                                    .map(Pair::getFirst)
                                                                                    .getOrThrow());*/
                singleFluidStorage.readData(view);
            }
            else
                //noinspection DataFlowIssue
                throw new UnsupportedOperationException("Unsupported storage type: " + storage.getClass().getName());

            index++;
        }
    }
}