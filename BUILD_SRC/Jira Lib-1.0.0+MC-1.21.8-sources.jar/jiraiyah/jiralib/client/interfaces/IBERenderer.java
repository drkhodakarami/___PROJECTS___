/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiralib.client.interfaces;

import jiraiyah.jibase.annotations.*;
import net.minecraft.class_243;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_4587;
import net.minecraft.class_4597;
import net.minecraft.class_5614;
import net.minecraft.class_765;
import net.minecraft.class_8012;
import org.joml.Matrix4f;

@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public interface IBERenderer<T extends class_2586>
{
    default void renderTag(T blockEntity, String inputText,
                           class_5614.class_5615 context, class_4587 matrices, class_4597 vertexConsumer,
                           class_243 vec3d, float tickData, int light, int overlay)
    {
        class_2561 text = class_2561.method_43470(inputText);

        matrices.method_22903();
        {
            matrices.method_22904(vec3d.field_1352, vec3d.field_1351, vec3d.field_1350);
            matrices.method_22907(class_310.method_1551().field_1773.method_19418().method_23767());
            matrices.method_22905(0.025f, -0.025f, 0.025f);
            Matrix4f matrix4f = matrices.method_23760().method_23761();
            class_327 textRenderer = context.method_32143();
            float f = -textRenderer.method_27525(text) / 2.0f;
            int j = (int) (class_310.method_1551().field_1690.method_19343(0.25f) * 255f) << 24;
            textRenderer.method_27522(text, f, 1, -2130706433, false, matrix4f, vertexConsumer,
                              class_327.class_6415.field_33994, j, light);
            textRenderer.method_27522(text, f, 1, class_8012.field_42973, false, matrix4f, vertexConsumer,
                              class_327.class_6415.field_33993, 0, class_765.method_62228(light, 2));
        }
        matrices.method_22909();
    }
}