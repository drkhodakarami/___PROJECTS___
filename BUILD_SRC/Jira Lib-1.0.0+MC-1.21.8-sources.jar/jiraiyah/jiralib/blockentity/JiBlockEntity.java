/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiralib.blockentity;

import com.mojang.logging.LogUtils;
import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.interfaces.ISyncedTick;
import jiraiyah.jibase.interfaces.IUpdatable;
import jiraiyah.jibase.properties.BEProperties;
import net.minecraft.class_11362;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2487;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_2596;
import net.minecraft.class_2602;
import net.minecraft.class_2622;
import net.minecraft.class_2680;
import net.minecraft.class_7225;
import net.minecraft.class_8942;
import org.jetbrains.annotations.Nullable;
import org.slf4j.Logger;

@SuppressWarnings("unused")
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@ThanksTo(discordUsers = "TheWhyEvenHow")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")
public abstract class JiBlockEntity<T extends JiBlockEntity<T>> extends class_2586 implements IUpdatable, ISyncedTick
{
    protected boolean isDirty = false;
    protected boolean isDirtyClient = false;
    protected int ticks;
    protected int clientTicks;

    protected BEProperties<T> properties;

    @SuppressWarnings("unchecked")
    public JiBlockEntity(class_2591<T> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
        properties = new BEProperties<>((T)this);
    }

    @Override
    public void update()
    {
        this.isDirty = true;

        if(this.properties!= null && !this.properties.isWaitingEndTick())
        {
            method_5431();

            if(this.field_11863 != null && !this.field_11863.field_9236)
                this.field_11863.method_8413(this.field_11867, method_11010(), method_11010(), class_2248.field_31036);
        }
    }

    @Override
    public void onTickEnd()
    {
        if(this.isDirty)
        {
            this.isDirty = false;
            method_5431();
            if(this.field_11863 != null && !this.field_11863.field_9236)
                this.field_11863.method_8413(this.field_11867, method_11010(), method_11010(), class_2248.field_31036);
        }
    }

    @Override
    public @Nullable class_2596<class_2602> method_38235()
    {
        return class_2622.method_38585(this);
    }

    @Override
    public class_2487 method_16887(class_7225.class_7874 registries)
    {
        class_2487 nbt = super.method_16887(registries);
        Logger logger = LogUtils.getLogger();
        try (class_8942.class_11340 logging = new class_8942.class_11340(this.method_71402(), logger)) {
            class_11362 view = class_11362.method_71459(logging, registries);
            method_11007(view);
            return view.method_71475();
        }
    }

    @Override
    public void onTick()
    {
        if(this.ticks == 0)
            this.onInternalFirstTick();

        if(this.properties.getTickRate() == 0 || (this.ticks % this.properties.getTickRate() == 0))
            this.onInternalTick();

        this.ticks++;
    }

    @Override
    public void onTickClient()
    {
        if(this.clientTicks == 0)
            this.onInternalFirstTickClient();

        if(this.properties.getTickRate() == 0 || (this.clientTicks % this.properties.getTickRate() == 0))
            this.onInternalTickClient();

        this.clientTicks++;
    }

    @Override
    public boolean shouldSync()
    {
        return this.properties.isSynced();
    }

    protected void registerDefaultFields()
    {
        this.properties.fields().addField("isDirty", this.isDirty, blockEntity -> blockEntity.isDirty, ((blockEntity, value) -> blockEntity.isDirty = value));
        this.properties.fields().addField("isDirtyClient", this.isDirtyClient, blockEntity -> blockEntity.isDirtyClient, ((blockEntity, value) -> blockEntity.isDirtyClient = value));
        this.properties.fields().addField("ticks", this.ticks, blockEntity -> blockEntity.ticks, ((blockEntity, value) -> blockEntity.ticks = value));
        this.properties.fields().addField("ticksClient", this.clientTicks, blockEntity -> blockEntity.clientTicks, ((blockEntity, value) -> blockEntity.clientTicks = value));

        this.properties.fields().addField("world", this.field_11863, JiBlockEntity::method_10997, null);
        this.properties.fields().addField("pos", this.field_11867, JiBlockEntity::method_11016, null);
        this.properties.fields().addField("cachedState", method_11010(), JiBlockEntity::method_11010, null);
    }

    public int getTicks()
    {
        return this.ticks;
    }

    public int getTicksClient()
    {
        return this.clientTicks;
    }

    private void onInternalFirstTick()
    {
        registerDefaultFields();
        registerFields();
        onFirstTick();
    }

    private void onInternalFirstTickClient()
    {
        onFirstTickClient();
    }

    private void onInternalTick()
    {
        if(this.properties.tickLogic() != null)
            this.properties.tickLogic().tick(this.properties);
    }

    private void onInternalTickClient()
    {
        if(this.properties.tickLogic() != null)
            this.properties.tickLogic().tickClient(this.properties);
    }

    protected void onFirstTick() {}
    protected void onFirstTickClient() {}
    protected void registerFields() {}
}