/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiralib.block;

import com.mojang.serialization.MapCodec;
import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.interfaces.IBEScreen;
import jiraiyah.jibase.interfaces.ITick;
import jiraiyah.jibase.properties.BlockProperties;
import jiraiyah.jiralib.interfaces.BlockStateManagerAccessor;
import net.minecraft.block.*;
import net.minecraft.class_10225;
import net.minecraft.class_1264;
import net.minecraft.class_1269;
import net.minecraft.class_1657;
import net.minecraft.class_1750;
import net.minecraft.class_1922;
import net.minecraft.class_1937;
import net.minecraft.class_2246;
import net.minecraft.class_2248;
import net.minecraft.class_2338;
import net.minecraft.class_2343;
import net.minecraft.class_2350;
import net.minecraft.class_2415;
import net.minecraft.class_2464;
import net.minecraft.class_2470;
import net.minecraft.class_2586;
import net.minecraft.class_2591;
import net.minecraft.class_265;
import net.minecraft.class_2680;
import net.minecraft.class_2689;
import net.minecraft.class_2741;
import net.minecraft.class_3218;
import net.minecraft.class_3222;
import net.minecraft.class_3726;
import net.minecraft.class_3965;
import net.minecraft.class_4538;
import net.minecraft.class_5558;
import net.minecraft.class_5819;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("unused")
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@ThanksTo(discordUsers = "TheWhyEvenHow")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")

public abstract class JiBlock extends class_2248 implements class_2343
{
    public static MapCodec<? extends JiBlock> CODEC;

    protected BlockProperties<?> properties;

    public JiBlock(class_2251 settings, BlockProperties<?> properties)
    {
        super(settings);
        this.properties = properties;

        class_2689.class_2690<class_2248, class_2680> builder = new class_2689.class_2690<>(this);
        method_9515(builder);

        ((BlockStateManagerAccessor) this).setStateManager(builder.method_11668(class_2248::method_9564, class_2680::new));
        method_9590(this.field_10647.method_11664());

        class_2680 state = this.field_10647.method_11664();
        state = this.properties.getStateProperties().applyDefaults(state);
        method_9590(state);
    }

    @Override
    protected void method_9515(class_2689.class_2690<class_2248, class_2680> builder)
    {
        super.method_9515(builder);

        if (this.properties != null && this.properties.getStateProperties() != null)
            this.properties.getStateProperties().addToBuilder(builder);
    }

    @Override
    public @Nullable class_2680 method_9605(class_1750 ctx)
    {
        class_2680 state = super.method_9605(ctx);
        if(state == null)
            return null;

        if(this.properties.getStateProperties().containsProperty(class_2741.field_12481))
        {
            class_2350 facing = ctx.method_8042();
            if(this.properties.isFacingOpposite())
                facing = facing.method_10153();
            state = state.method_11657(class_2741.field_12481, facing);
        }
        else if(this.properties.getStateProperties().containsProperty(class_2741.field_12525))
        {
            class_2350 facing = ctx.method_7715();
            if(this.properties.isFacingOpposite())
                facing = facing.method_10153();
            state = state.method_11657(class_2741.field_12525, facing);
        }

        if(this.properties.getStateProperties().containsProperty(class_2741.field_12496))
        {
            state = state.method_11657(class_2741.field_12496, ctx.method_8038().method_10166());
        }

        return state;
    }

    @Override
    protected class_2680 method_9598(class_2680 state, class_2470 rotation)
    {
        if(this.properties.getStateProperties().containsProperty(class_2741.field_12481))
            return state.method_11657(class_2741.field_12481, rotation.method_10503(state.method_11654(class_2741.field_12481)));
        else if(this.properties.getStateProperties().containsProperty(class_2741.field_12525))
            return state.method_11657(class_2741.field_12525, rotation.method_10503(state.method_11654(class_2741.field_12525)));

        return super.method_9598(state, rotation);
    }

    @Override
    protected class_2680 method_9569(class_2680 state, class_2415 mirror)
    {
        if(this.properties.getStateProperties().containsProperty(class_2741.field_12481))
            return state.method_11657(class_2741.field_12481, mirror.method_10343(state.method_11654(class_2741.field_12481)));
        else if(this.properties.getStateProperties().containsProperty(class_2741.field_12525))
            return state.method_11657(class_2741.field_12525, mirror.method_10343(state.method_11654(class_2741.field_12525)));

        return super.method_9569(state, mirror);
    }

    @Override
    public @Nullable class_2586 method_10123(class_2338 pos, class_2680 state)
    {
        return (this.properties.getBEType() != null && this.properties.getBEFactory() != null)
                ? this.properties.getBEFactory().create(pos, state)
                : null;
    }

    @Override
    public @Nullable <T extends class_2586> class_5558<T> method_31645(class_1937 world, class_2680 state, class_2591<T> type)
    {
        if(this.properties.getBEType() == null && this.properties.isTickable())
            throw new IllegalArgumentException("BlockEntityType supplier cannot be null or return null when you want a ticking block entity! Check your constructor's properties. Either remove the .tick method call or add a block entity supplier!");
        if(this.properties.getBEType() != null && this.properties.isTickable())
        {
            if(this.properties.getBEType() instanceof ITick)
                //noinspection ResultOfMethodCallIgnored
                ITick.createTicker(world);
            else
                getBETicker(world, state, type);
        }
        return null;
    }

    @SuppressWarnings("UnusedReturnValue")
    protected <T extends class_2586> class_5558<T> getBETicker(class_1937 world, class_2680 state, class_2591<T> type)
    {
        //EXAMPLE USAGE FOR VANILLA BLOCKS WITHOUT THE INTERFACE IMPLEMENTATION
        /*return validateTicker(this.properties.blockEntityProperties().getBlockEntityType(),
                              (world1, pos, state1, blockEntity) ->
                              {
                                  blockEntity.tick(world1, pos, state1);
                              });*/
        return class_2343.super.method_31645(world, state, type);
    }

    protected static <E extends class_2586, A extends class_2586> class_5558<A> validateTicker(class_2591<A> givenType, class_2591<E> expectedType, class_5558<? super E> ticker) {
        //noinspection unchecked
        return expectedType == givenType ? (class_5558<A>) ticker : null;
    }

    @Override
    protected boolean method_9498(class_2680 state)
    {
        return this.properties.hasComparatorOutput();
    }

    @Override
    protected int method_9572(class_2680 state, class_1937 world, class_2338 pos)
    {
        return this.properties.hasComparatorOutput()
               ? this.properties.getComparatorOutput().apply(state, world, pos)
               : super.method_9572(state, world, pos);
    }

    @Override
    protected class_2464 method_9604(class_2680 state)
    {
        return this.properties.getRenderType();
    }

    @Override
    protected class_265 method_9530(class_2680 state, class_1922 world, class_2338 pos, class_3726 context)
    {
        return this.properties.getShapeFactory().create(state, world, pos, context);
    }

    @Override
    protected void method_66388(class_2680 state, class_3218 world, class_2338 pos, boolean moved)
    {
        class_1264.method_66221(state, world, pos);
    }

    @Override
    protected class_1269 method_55766(class_2680 state, class_1937 world, class_2338 pos, class_1657 player, class_3965 hit)
    {
        if (this.properties.hasGUI())
        {
            if(this.properties.getBEType() == null)
                throw new IllegalArgumentException("BlockEntityType supplier cannot be null or return null when you want a gui on block entity! Check your constructor's properties. Either remove the .addGui method call or add a block entity supplier!");
            if (!world.field_9236)
            {
                class_2586 blockEntity = world.method_8321(pos);
                if (player instanceof class_3222 sPlayer && blockEntity instanceof IBEScreen<?> blockEntityWithGui)
                {
                    sPlayer.method_17355(blockEntityWithGui);
                }
            }

            return class_1269.field_5812;
        }

        return class_1269.field_5812;
    }

    @Override
    protected boolean method_9558(class_2680 state, class_4538 world, class_2338 pos)
    {
        return this.properties.canExistAt().test(world, pos);
    }

    @Override
    protected class_2680 method_9559(class_2680 state, class_4538 world, class_10225 tickView, class_2338 pos, class_2350 direction, class_2338 neighborPos, class_2680 neighborState, class_5819 random)
    {
        return !state.method_26184(world, pos)
                ? class_2246.field_10124.method_9564()
                : super.method_9559(state, world, tickView, pos, direction, neighborPos, neighborState, random);
    }

    @Override
    protected MapCodec<? extends class_2248> method_53969()
    {
        return field_46280;
    }

    public boolean hasInventory()
    {
        if(this.properties.getBEType() == null && this.properties.hasInventory())
            throw new IllegalArgumentException("BlockEntityType supplier cannot be null or return null when you want an inventory on block entity! Check your constructor's properties. Either remove the .addInventory method call or add a block entity supplier!");
        return this.properties.hasInventory();
    }
}