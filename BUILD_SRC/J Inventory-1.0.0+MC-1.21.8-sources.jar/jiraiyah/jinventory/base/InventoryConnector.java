/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jinventory.base;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.constants.BEKeys;
import jiraiyah.jibase.enumerations.MappedDirection;
import jiraiyah.jibase.interfaces.IStorageConnector;
import jiraiyah.jibase.interfaces.IStorageProvider;
import jiraiyah.jibase.utils.PosHelper;
import jiraiyah.jinventory.storage.OutputInventory;
import jiraiyah.jinventory.storage.RecipeInventory;
import jiraiyah.jinventory.record.PredicateInventoryStorage;
import jiraiyah.jiralib.util.StorageConnector;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.fabricmc.fabric.api.transfer.v1.item.ItemVariant;
import net.fabricmc.fabric.api.transfer.v1.storage.base.CombinedStorage;
import net.fabricmc.fabric.api.transfer.v1.storage.base.SingleSlotStorage;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1262;
import net.minecraft.class_1263;
import net.minecraft.class_1264;
import net.minecraft.class_1277;
import net.minecraft.class_1657;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2586;
import org.jetbrains.annotations.NotNull;
import org.jetbrains.annotations.Nullable;
import oshi.util.tuples.Pair;

import java.util.ArrayList;
import java.util.List;
import java.util.function.BiFunction;
import java.util.function.Function;
import java.util.function.Supplier;

@SuppressWarnings("unused")
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")

public class InventoryConnector<T extends class_1277> extends StorageConnector<InventoryStorage>
    implements IStorageConnector<InventoryConnector<T>>, IStorageProvider<InventoryStorage>
{
    private final List<T> inventories = new ArrayList<>();
    private final List<Pair<MappedDirection, T>> sidedInventories = new ArrayList<>();

    private final CombinedStorage<ItemVariant, InventoryStorage> combinedStorage = new CombinedStorage<>(this.storages);

    //region ADD INVENTORY
    public void addStorage(@NotNull T inventory) {
        addStorage(inventory, MappedDirection.NONE);
    }

    public void addStorage(@NotNull T inventory, MappedDirection side)
    {
        this.inventories.add(inventory);
        this.sidedInventories.add(new Pair<>(side, inventory));
        var storage = InventoryStorage.of(inventory, MappedDirection.toDirection(side));
        addStorage(storage, side);
    }

    public void addStorage(@NotNull T inventory, class_2350 side)
    {
        addStorage(inventory, MappedDirection.fromDirection(side));
    }

    public void addStorage(@NotNull T inventory, Supplier<Boolean> canInsert, Supplier<Boolean> canExtract) {
        addStorage(inventory, MappedDirection.NONE, canInsert, canExtract);
    }

    public void addStorage(@NotNull T inventory, MappedDirection side, Supplier<Boolean> canInsert, Supplier<Boolean> canExtract)
    {
        this.inventories.add(inventory);
        this.sidedInventories.add(new Pair<>(side, inventory));
        var storage = PredicateInventoryStorage.of(InventoryStorage.of(inventory, MappedDirection.toDirection(side)), canInsert, canExtract);
        addStorage(storage, side);
    }

    public void addStorage(@NotNull T inventory, class_2350 side, Supplier<Boolean> canInsert, Supplier<Boolean> canExtract)
    {
        this.addStorage(inventory, MappedDirection.fromDirection(side), canInsert, canExtract);
    }

    public void addStorage(int size, Function<Integer, T> factory)
    {
        addStorage(factory.apply(size));
    }

    public void addStorage(int size, MappedDirection side, Function<Integer, T> factory)
    {
        addStorage(factory.apply(size), side);
    }

    public void addStorage(int size, class_2350 side, Function<Integer, T> factory)
    {
        addStorage(factory.apply(size), side);
    }

    public void addStorage(Function<class_1799[], T> factory, class_1799... items)
    {
        addStorage(factory.apply(items));
    }

    public void addStorage(MappedDirection side, Function<class_1799[], T> factory, class_1799... items)
    {
        addStorage(factory.apply(items), side);
    }

    //recipe, simple
    public void addStorage(class_2350 side, Function<class_1799[], T> factory, class_1799... items)
    {
        addStorage(factory.apply(items), side);
    }

    //Used for synced, output, predicate
    public void addStorage(class_2586 blockEntity, int size, BiFunction<class_2586, Integer, T> factory)
    {
        addStorage(factory.apply(blockEntity, size));
    }

    public void addStorage(class_2586 blockEntity, int size, MappedDirection side, BiFunction<class_2586, Integer, T> factory)
    {
        addStorage(factory.apply(blockEntity, size), side);
    }

    public void addStorage(class_2586 blockEntity, int size, class_2350 side, BiFunction<class_2586, Integer, T> factory)
    {
        addStorage(factory.apply(blockEntity, size), side);
    }

    public void addStorage(class_2586 blockEntity, BiFunction<class_2586, class_1799[], T> factory, class_1799... items)
    {
        addStorage(factory.apply(blockEntity, items));
    }

    public void addStorage(class_2586 blockEntity, MappedDirection side, BiFunction<class_2586, class_1799[], T> factory, class_1799... items)
    {
        addStorage(factory.apply(blockEntity, items), side);
    }

    public void addStorage(class_2586 blockEntity, class_2350 side, BiFunction<class_2586, class_1799[], T> factory, class_1799... items)
    {
        addStorage(factory.apply(blockEntity, items), side);
    }
    //endregion

    //region ADD INSERT / EXTRACT ONLY
    public void addInsertOnlyInventory(@NotNull T inventory, MappedDirection side)
    {
        addInsertOnlyInventory(inventory, side, () -> true);
    }

    public void addInsertOnlyInventory(@NotNull T inventory, MappedDirection side, Supplier<Boolean> canInsert)
    {
        addStorage(inventory, side, canInsert, () -> false);
    }

    public void addExtractOnlyInventory(@NotNull T inventory, MappedDirection side)
    {
        addExtractOnlyInventory(inventory, side, () -> true);
    }

    public void addExtractOnlyInventory(@NotNull T inventory, MappedDirection side, Supplier<Boolean> canExtract)
    {
        addStorage(inventory, side, () -> false, canExtract);
    }

    public void addInsertOnlyInventory(@NotNull T inventory, class_2350 side)
    {
        addInsertOnlyInventory(inventory, side, () -> true);
    }

    public void addInsertOnlyInventory(@NotNull T inventory, class_2350 side, Supplier<Boolean> canInsert)
    {
        addStorage(inventory, side, canInsert, () -> false);
    }

    public void addExtractOnlyInventory(@NotNull T inventory, class_2350 side)
    {
        addExtractOnlyInventory(inventory, side, () -> true);
    }

    public void addExtractOnlyInventory(@NotNull T inventory, class_2350 side, Supplier<Boolean> canExtract)
    {
        addStorage(inventory, side, () -> false, canExtract);
    }
    //endregion

    public List<T> getInventories()
    {
        return inventories;
    }

    public CombinedStorage<ItemVariant, InventoryStorage> getCombinedStorage()
    {
        return combinedStorage;
    }

    //region GET INVENTORY
    public @Nullable T getInventory(int index)
    {
        return this.inventories.get(index);
    }

    public @Nullable T getInventory(MappedDirection side)
    {
        return this.inventories.get(this.storages.indexOf(getStorage(side)));
    }

    public @Nullable T getInventory(class_2350 side)
    {
        return this.inventories.get(this.storages.indexOf(getStorage(side)));
    }
    //endregion

    //region GET SLOT(S)
    public @Nullable SingleSlotStorage<ItemVariant> getSlot(int slotIndex, MappedDirection side)
    {
        return this.getStorage(side).getSlot(slotIndex);
    }

    public @Nullable SingleSlotStorage<ItemVariant> getSlot(int slotIndex, class_2350 side)
    {
        return this.getStorage(side).getSlot(slotIndex);
    }

    public @Nullable SingleSlotStorage<ItemVariant> getSlot(int slotIndex, int index)
    {
        return this.getStorage(index).getSlot(slotIndex);
    }

    public @Nullable List<SingleSlotStorage<ItemVariant>> getSlots(MappedDirection side)
    {
        return this.getStorage(side).getSlots();
    }

    public @Nullable List<SingleSlotStorage<ItemVariant>> getSlots(class_2350 side)
    {
        return this.getStorage(side).getSlots();
    }

    public @Nullable List<SingleSlotStorage<ItemVariant>> getSlots(int index)
    {
        return this.getStorage(index).getSlots();
    }
    //endregion

    public @NotNull List<class_1799> getStacks()
    {
        List<class_1799> stacks = new ArrayList<>();
        for (T inventory : this.inventories)
            for(int i = 0; i < inventory.method_5439(); i++)
                stacks.add(inventory.method_5438(i));
        return stacks;
    }

    public void checkSize(int size)
    {
        int invSize = this.inventories.stream().map(class_1263::method_5439).reduce(0, Integer::sum);
        if( invSize != size)
            throw new IllegalArgumentException("Sie of inventories does not match the size provided: " + invSize + " => " + size);
    }

    public void onOpen(@NotNull class_1657 player)
    {
        this.inventories.forEach(inventory -> inventory.method_5435(player));
    }

    public void onClose(@NotNull class_1657 player)
    {
        this.inventories.forEach(inventory -> inventory.method_5432(player));
    }

    public void dropContent(@NotNull class_1937 world, @NotNull class_2338 pos)
    {
        this.inventories.forEach(inventory -> class_1264.method_5451(world, pos, inventory));
    }

    public RecipeInventory getRecipeInventory()
    {
        return new RecipeInventory(getStacks().toArray(new class_1799[0]));
    }

    public List<Pair<MappedDirection, T>> getSidedInventories()
    {
        return this.sidedInventories;
    }

    @Override
    public InventoryConnector<T> getConnector()
    {
        return this;
    }

    @Override
    public InventoryStorage getStorageProvider(MappedDirection direction, class_2350 facing)
    {

        class_2350 side = PosHelper.relativeDirection(MappedDirection.toDirection(direction), facing);
        if(this.getSidedMap().containsKey(MappedDirection.fromDirection(side)))
            return getStorage(side);
        return null;
    }

    @Override
    public InventoryStorage getStorageProvider(class_2350 direction, class_2350 facing)
    {
        class_2350 side = PosHelper.relativeDirection(direction, facing);
        if(this.getSidedMap().containsKey(MappedDirection.fromDirection(side)))
            return getStorage(side);
        return null;
    }

    @Override
    public void writeData(class_11372 writeView)
    {
        class_11372.class_11374 listView = writeView.method_71476("inventory" + BEKeys.HAS_INVENTORY);
        for (T inventory : inventories)
        {
            class_11372 compoundView = listView.method_71480();
            class_1262.method_5426(compoundView, inventory.method_54454());
        }
    }

    @Override
    public void readData(class_11368 readView)
    {
        int index = 0;
        for (class_11368 view : readView.method_71438("inventory" + BEKeys.HAS_INVENTORY))
        {
            if(index >= inventories.size())
                break;
            class_1262.method_5429(view, inventories.get(index).method_54454());
            index++;
        }
    }
}