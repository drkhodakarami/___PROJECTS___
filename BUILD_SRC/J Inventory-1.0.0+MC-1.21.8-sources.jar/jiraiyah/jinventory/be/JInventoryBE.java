package jiraiyah.jinventory.be;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.constants.BEKeys;
import jiraiyah.jibase.enumerations.MappedDirection;
import jiraiyah.jibase.interfaces.IStorageConnector;
import jiraiyah.jibase.interfaces.IStorageProvider;
import jiraiyah.jibase.records.BlockPosPayload;
import jiraiyah.jinventory.base.InventoryConnector;
import jiraiyah.jinventory.interfaces.IContentDrop;
import jiraiyah.jinventory.storage.OutputInventory;
import jiraiyah.jiralib.block.JiBlock;
import jiraiyah.jiralib.blockentity.JiScreenBE;
import net.fabricmc.fabric.api.transfer.v1.item.InventoryStorage;
import net.minecraft.class_11368;
import net.minecraft.class_11372;
import net.minecraft.class_1277;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2591;
import net.minecraft.class_2680;
import net.minecraft.class_2741;
import net.minecraft.class_3222;
import org.jetbrains.annotations.Nullable;
/**
 * Abstract base class for block entities that support inventory storage.
 *
 * <p>This class extends {@link JiScreenBE} and implements the {@link IContentDrop}, {@link IStorageProvider},
 * and {@link IStorageConnector} interfaces, providing a framework for managing inventory contents and storage connections.</p>
 *
 * @param <T> The type of this block entity.
 * @param <B> The type of the inventory used by this block entity.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")
public abstract class JInventoryBE<T extends JInventoryBE<T, B>, B extends class_1277> extends JiScreenBE<T, BlockPosPayload>
    implements IContentDrop<B>, IStorageProvider<InventoryStorage>, IStorageConnector<InventoryConnector<?>>
{
    protected final InventoryConnector<B> inventory;

    /**
     * Constructs a new instance of JInventoryBE.
     *
     * @param type The block entity type.
     * @param pos  The position of the block entity.
     * @param state The block state of the block entity.
     */
    public JInventoryBE(class_2591<T> type, class_2338 pos, class_2680 state)
    {
        super(type, pos, state);
        inventory = new InventoryConnector<>();
        this.properties.update()
                        .sync()
                        .waitEndTick();
    }

    /**
     * Retrieves the screen opening data for a server player entity.
     *
     * @param serverPlayerEntity The server player entity.
     * @return A {@link BlockPosPayload} containing the block position of this block entity.
     */
    @Override
    public BlockPosPayload getScreenOpeningData(class_3222 serverPlayerEntity)
    {
        return new BlockPosPayload(this.field_11867);
    }

    /**
     * Retrieves the inventory connector associated with this block entity.
     *
     * @return The {@link InventoryConnector} instance for this block entity.
     */
    @Override
    public InventoryConnector<B> getInventoryConnector()
    {
        return inventory;
    }

    /**
     * Retrieves the storage provider for a given mapped direction and facing direction.
     *
     * @param mappedDirection The mapped direction.
     * @param facing          The facing direction.
     * @return The {@link InventoryStorage} instance or null if not available.
     */
    @Override
    public @Nullable InventoryStorage getStorageProvider(MappedDirection mappedDirection, class_2350 facing)
    {
        return this.inventory.getStorageProvider(MappedDirection.toDirection(mappedDirection), facing);
    }

    /**
     * Retrieves the storage provider for a given direction and facing direction.
     *
     * @param direction The direction.
     * @param facing    The facing direction.
     * @return The {@link InventoryStorage} instance or null if not available.
     */
    @Override
    public @Nullable InventoryStorage getStorageProvider(class_2350 direction, class_2350 facing)
    {
        return this.inventory.getStorageProvider(direction, facing);
    }

    /**
     * Retrieves the storage connector associated with this block entity.
     *
     * @return The {@link InventoryConnector} instance for this block entity.
     */
    @Override
    public InventoryConnector<?> getConnector()
    {
        return this.inventory;
    }

    /**
     * Reads data from a read view and populates this block entity's state and inventory.
     *
     * @param view The read view containing the data to be read.
     */
    @Override
    protected void method_11014(class_11368 view)
    {
        super.method_11014(view);
        inventory.readData(view);
    }

    /**
     * Writes data from this block entity's state and inventory to a write view.
     *
     * @param view The write view where the data will be written.
     */
    @Override
    protected void method_11007(class_11372 view)
    {
        super.method_11007(view);
        inventory.writeData(view);
    }

    /**
     * Handles block replacement logic, including dropping inventory contents if applicable.
     *
     * @param pos      The position of the block being replaced.
     * @param oldState The state of the old block.
     */
    @Override
    public void method_66473(class_2338 pos, class_2680 oldState)
    {
        if(field_11863 == null || !(field_11863.method_8320(pos).method_26204() instanceof JiBlock block))
            return;
        if(block.hasInventory())
        {
            if(!oldState.method_27852(field_11863.method_8320(pos).method_26204()))
                this.dropContent(field_11863, pos);
        }
    }

    /**
     * Retrieves the inventory storage for a given direction.
     *
     * @param direction The direction for which to retrieve the inventory storage.
     * @return The {@link InventoryStorage} instance or null if not available.
     */
    public InventoryStorage getInventoryStorage(class_2350 direction)
    {
        if(field_11863 == null)
            return null;
        if(field_11863.method_8320(field_11867).method_28501().contains(class_2741.field_12525))
            return this.inventory.getStorageProvider(direction, field_11863.method_8320(field_11867).method_11654(class_2741.field_12525));
        return this.inventory.getStorage(direction);
    }

    /**
     * Retrieves the inventory storage for a given mapped direction.
     *
     * @param direction The mapped direction for which to retrieve the inventory storage.
     */
    public InventoryStorage getInventoryStorage(MappedDirection direction)
    {
        return getInventoryStorage(MappedDirection.toDirection(direction));
    }
}