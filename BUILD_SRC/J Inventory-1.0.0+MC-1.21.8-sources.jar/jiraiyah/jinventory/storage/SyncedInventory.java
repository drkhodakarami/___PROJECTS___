/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jinventory.storage;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.interfaces.ISyncable;
import jiraiyah.jiralib.blockentity.JiBlockEntity;
import net.minecraft.class_1799;
import net.minecraft.class_2586;
import org.jetbrains.annotations.Nullable;

@SuppressWarnings("unused")
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")

public class SyncedInventory extends RecipeInventory implements ISyncable
{
    private final class_2586 blockEntity;
    private boolean isDirty = false;

    public SyncedInventory(class_2586 blockEntity, int size)
    {
        super(size);
        this.blockEntity = blockEntity;
    }

    public SyncedInventory(class_2586 blockEntity, class_1799... items)
    {
        super(items);
        this.blockEntity = blockEntity;
    }

    @Override
    public void sync()
    {
        //noinspection DataFlowIssue
        if(this.isDirty && this.blockEntity != null && this.blockEntity.method_11002() && !this.blockEntity.method_10997().field_9236)
        {
            this.isDirty = false;
            if(this.blockEntity instanceof JiBlockEntity<?> be)
                be.update();
            else
                this.blockEntity.method_5431();
        }
    }

    @Override
    public void method_5431()
    {
        super.method_5431();
        this.isDirty = true;
    }

    public class_2586 getBlockEntity()
    {
        return this.blockEntity;
    }

    @Nullable
    public JiBlockEntity<?> getJiBlockEntity()
    {
        if(this.blockEntity instanceof JiBlockEntity<?> be)
            return be;
        return  null;
    }
}