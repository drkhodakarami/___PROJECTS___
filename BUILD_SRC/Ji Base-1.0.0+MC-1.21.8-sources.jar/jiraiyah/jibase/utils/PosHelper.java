/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.utils;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.exceptions.Exceptions;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_2382;
import net.minecraft.class_241;
import net.minecraft.class_243;
import net.minecraft.util.math.*;
import org.jetbrains.annotations.Nullable;

/**
 * Provides utility methods for position-related operations in Minecraft.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class PosHelper
{
    /**
     * Private constructor to prevent instantiation.
     */
    public PosHelper()
    {
        Exceptions.throwCtorAssertion();
    }

    /**
     * Retrieves an array of positions next to the given block position (up, down, east, west, north, south).
     *
     * @param pos The base block position.
     * @return An array of adjacent block positions.
     */
    public static class_2338[] positionNextTo(class_2338 pos)
    {
        return new class_2338[]{pos.method_10084(), pos.method_10074(), pos.method_10078(), pos.method_10067(), pos.method_10095(), pos.method_10072()};
    }

    /**
     * Retrieves an array of positions adjacent to the given block position (east, west, north, south).
     *
     * @param pos The base block position.
     * @return An array of adjacent block positions.
     */
    public static class_2338[] positionSideTo(class_2338 pos)
    {
        return new class_2338[]{pos.method_10078(), pos.method_10067(), pos.method_10095(), pos.method_10072()};
    }

    /**
     * Retrieves an array of positions adjacent to the given block position (down, east, west, north, south).
     *
     * @param pos The base block position.
     * @return An array of adjacent block positions.
     */
    public static class_2338[] positionSideBottom(class_2338 pos)
    {
        return new class_2338[]{pos.method_10074(), pos.method_10078(), pos.method_10067(), pos.method_10095(), pos.method_10072()};
    }

    /**
     * Retrieves an array of positions adjacent to the given block position (up, east, west, north, south).
     *
     * @param pos The base block position.
     * @return An array of adjacent block positions.
     */
    public static class_2338[] positionSideTop(class_2338 pos)
    {
        return new class_2338[]{pos.method_10084(), pos.method_10078(), pos.method_10067(), pos.method_10095(), pos.method_10072()};
    }

    /**
     * Retrieves an array of positions above and below the given block position (up, down).
     *
     * @param pos The base block position.
     * @return An array of adjacent block positions.
     */
    public static class_2338[] positionTopBottom(class_2338 pos)
    {
        return new class_2338[]{pos.method_10084(), pos.method_10074()};
    }

    /**
     * Determines the direction to the left of the given facing direction.
     *
     * @param facing The current facing direction.
     * @return The direction to the left.
     */
    public static class_2350 left(class_2350 facing)
    {
        return switch (facing)
        {
            case field_11043 -> class_2350.field_11039;
            case field_11035 -> class_2350.field_11034;
            case field_11039 -> class_2350.field_11035;
            case field_11034 -> class_2350.field_11043;
            default -> facing;
        };
    }

    /**
     * Determines the direction to the right of the given facing direction.
     *
     * @param facing The current facing direction.
     * @return The direction to the right.
     */
    public static class_2350 right(class_2350 facing)
    {
        return switch (facing)
        {
            case field_11043 -> class_2350.field_11034;
            case field_11035 -> class_2350.field_11039;
            case field_11039 -> class_2350.field_11043;
            case field_11034 -> class_2350.field_11035;
            default -> facing;
        };
    }

    /**
     * Determines the direction in front of the given facing direction.
     *
     * @param facing The current facing direction.
     * @return The direction in front.
     */
    public static class_2350 front(class_2350 facing)
    {
        return switch (facing)
        {
            case field_11043 -> class_2350.field_11035;
            case field_11035 -> class_2350.field_11043;
            case field_11039 -> class_2350.field_11034;
            case field_11034 -> class_2350.field_11039;
            default -> facing;
        };
    }

    /**
     * Determines the direction behind the given facing direction.
     *
     * @param facing The current facing direction.
     * @return The direction behind.
     */
    public static class_2350 back(class_2350 facing)
    {
        return switch (facing)
        {
            case field_11043 -> class_2350.field_11043;
            case field_11035 -> class_2350.field_11035;
            case field_11039 -> class_2350.field_11039;
            case field_11034 -> class_2350.field_11034;
            default -> facing;
        };
    }

    /**
     * Returns the block position offset by the direction to the left of the given facing direction.
     *
     * @param pos The base block position.
     * @param facing The current facing direction.
     * @return The offset block position.
     */
    public static class_2338 left(class_2338 pos, class_2350 facing)
    {
        return pos.method_10093(left(facing));
    }

    /**
     * Returns the block position offset by the direction to the right of the given facing direction.
     *
     * @param pos The base block position.
     * @param facing The current facing direction.
     * @return The offset block position.
     */
    public static class_2338 right(class_2338 pos, class_2350 facing)
    {
        return pos.method_10093(right(facing));
    }

    /**
     * Returns the block position offset by the direction in front of the given facing direction.
     *
     * @param pos The base block position.
     * @param facing The current facing direction.
     * @return The offset block position.
     */
    public static class_2338 front(class_2338 pos, class_2350 facing)
    {
        return pos.method_10093(front(facing));
    }

    /**
     * Returns the block position offset by the direction behind the given facing direction.
     *
     * @param pos The base block position.
     * @param facing The current facing direction.
     * @return The offset block position.
     */
    public static class_2338 back(class_2338 pos, class_2350 facing)
    {
        return pos.method_10093(back(facing));
    }

    /**
     * Returns the block position above the given block position.
     *
     * @param pos The base block position.
     * @return The block position above.
     */
    public static class_2338 top(class_2338 pos)
    {
        return pos.method_10084();
    }

    /**
     * Returns the block position below the given block position.
     *
     * @param pos The base block position.
     * @return The block position below.
     */
    public static class_2338 bottom(class_2338 pos)
    {
        return pos.method_10074();
    }

    /**
     * Determines the relative direction based on a given direction and facing direction.
     *
     * @param direction The direction to convert.
     * @param facing The current facing direction.
     * @return The relative direction, or null if either parameter is null.
     */
    public static class_2350 relativeDirection(@Nullable class_2350 direction, @Nullable class_2350 facing)
    {
        if(direction == null)
            return null;
        if(facing == null)
            return direction;
        if(direction.method_10166().method_10178())
            return direction;

        class_2350 relative = direction;
        for (int i = 0; i < facing.ordinal(); i++)
            relative = relative.method_10170();
        return relative;
    }

    /**
     * Calculates the Euclidean distance between two block positions.
     *
     * @param pos The destination block position.
     * @param origin The starting block position.
     * @return The distance between the two positions.
     */
    public static double getDistance(class_2338 pos, class_2338 origin)
    {
        return Math.sqrt(Math.pow(pos.method_10263() - origin.method_10263(), 2) + Math.pow(pos.method_10264() - origin.method_10264(), 2) + Math.pow(pos.method_10260() - origin.method_10260(), 2));
    }

    /**
     * Calculates the Euclidean distance between two integer coordinates in a 3D space.
     *
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param z1 The z-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     * @param z2 The z-coordinate of the second point.
     * @return The distance between the two points.
     */
    public static double getDistance(int x1, int y1, int z1 , int x2, int y2, int z2)
    {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2) + Math.pow(z1 - z2, 2));
    }

    /**
     * Calculates the Euclidean distance between two integer coordinates in a 2D space.
     *
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     * @return The distance between the two points.
     */
    public static double getDistance(int x1, int y1 , int x2, int y2)
    {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    }

    /**
     * Calculates the Euclidean distance between two float coordinates in a 3D space.
     *
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param z1 The z-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     * @param z2 The z-coordinate of the second point.
     * @return The distance between the two points.
     */
    public static double getDistance(float x1, float y1, float z1 , float x2, float y2, float z2)
    {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2) + Math.pow(z1 - z2, 2));
    }

    /**
     * Calculates the Euclidean distance between two float coordinates in a 2D space.
     *
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     * @return The distance between the two points.
     */
    public static double getDistance(float x1, float y1 , float x2, float y2)
    {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    }

    /**
     * Calculates the Euclidean distance between two double coordinates in a 3D space.
     *
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param z1 The z-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     * @param z2 The z-coordinate of the second point.
     * @return The distance between the two points.
     */
    public static double getDistance(double x1, double y1, double z1 , double x2, double y2, double z2)
    {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2) + Math.pow(z1 - z2, 2));
    }

    /**
     * Calculates the Euclidean distance between two double coordinates in a 2D space.
     *
     * @param x1 The x-coordinate of the first point.
     * @param y1 The y-coordinate of the first point.
     * @param x2 The x-coordinate of the second point.
     * @param y2 The y-coordinate of the second point.
     * @return The distance between the two points.
     */
    public static double getDistance(double x1, double y1 , double x2, double y2)
    {
        return Math.sqrt(Math.pow(x1 - x2, 2) + Math.pow(y1 - y2, 2));
    }

    /**
     * Calculates the Euclidean distance between two 2D points represented by {@link class_241}.
     *
     * @param point1 The first point.
     * @param point2 The second point.
     * @return The distance between the two points.
     */
    public static double getDistance(class_241 point1, class_241 point2)
    {
        return getDistance(point1.field_1343, point1.field_1342, point2.field_1343, point2.field_1342);
    }

    /**
     * Calculates the Euclidean distance between two 3D points represented by {@link class_2382}.
     *
     * @param point1 The first point.
     * @param point2 The second point.
     * @return The distance between the two points.
     */
    public static double getDistance(class_2382 point1, class_2382 point2)
    {
        return getDistance(point1.method_10263(), point1.method_10264(), point1.method_10260(), point2.method_10263(), point2.method_10264(), point2.method_10260());
    }

    /**
     * Calculates the Euclidean distance between two 3D points represented by {@link class_243}.
     *
     * @param point1 The first point.
     * @param point2 The second point.
     * @return The distance between the two points.
     */
    public static double getDistance(class_243 point1, class_243 point2)
    {
        return getDistance(point1.method_10216(), point1.method_10214(), point1.method_10215(), point2.method_10216(), point2.method_10214(), point2.method_10215());
    }
}