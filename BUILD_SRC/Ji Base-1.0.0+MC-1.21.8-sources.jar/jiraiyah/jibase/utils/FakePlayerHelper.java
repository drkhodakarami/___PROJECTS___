/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.utils;

import jiraiyah.jibase.annotations.CreatedAt;
import jiraiyah.jibase.annotations.Developer;
import jiraiyah.jibase.annotations.Repository;
import jiraiyah.jibase.annotations.Youtube;
import net.minecraft.class_1268;
import net.minecraft.class_1269;
import net.minecraft.class_1297;
import net.minecraft.class_1301;
import net.minecraft.class_1303;
import net.minecraft.class_1304;
import net.minecraft.class_1309;
import net.minecraft.class_1324;
import net.minecraft.class_1542;
import net.minecraft.class_1667;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2350;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_2680;
import net.minecraft.class_2846;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import net.minecraft.class_5131;
import net.minecraft.class_5134;
import net.minecraft.entity.*;
import org.jetbrains.annotations.Nullable;

import java.util.List;
import java.util.Optional;

/**
 * Provides utility methods for interacting with fake players in Minecraft.
 */
@SuppressWarnings({"unused", "SameParameterValue"})
@Developer("Direwolf20")
@CreatedAt("2025-04-18")
@Repository("https://github.com/Direwolf20-MC/JustDireThings")
@Youtube("https://www.youtube.com/@direwolf20")
public class FakePlayerHelper
{
    /**
     * Represents the result of an interaction with a fake player.
     */
    public record FakePlayerResult(class_1269 actionResult, class_1799 returnStack) {}

    /**
     * Adds attributes to a fake player based on the item they are holding.
     *
     * @param player    The fake player.
     * @param itemStack The item stack the player is holding.
     * @param equipmentSlot The equipment slot of the item stack.
     */
    protected static void addAttributes(UsefulFakePlayer player, class_1799 itemStack, class_1304 equipmentSlot)
    {
        class_5131 container = player.method_6127();
        if(!itemStack.method_7960())
        {
            itemStack.method_57354(equipmentSlot, (attribute, modifier) ->
            {
                class_1324 attributeInstance = container.method_45329(attribute);
                if(attributeInstance != null)
                {
                    attributeInstance.method_6202(modifier);
                    attributeInstance.method_26835(modifier);
                }
            });
        }
    }

    /**
     * Removes attributes from a fake player based on the item they were holding.
     *
     * @param player    The fake player.
     * @param itemStack The item stack the player was holding.
     * @param equipmentSlot The equipment slot of the item stack.
     */
    protected static void removeAttributes(UsefulFakePlayer player, class_1799 itemStack, class_1304 equipmentSlot)
    {
        class_5131 container = player.method_6127();
        if(!itemStack.method_7960())
        {
            itemStack.method_57354(equipmentSlot, (attribute, modifier) ->
            {
                class_1324 attributeInstance = container.method_45329(attribute);
                if(attributeInstance != null)
                    attributeInstance.method_6202(modifier);
            });
        }
    }

    /**
     * Sets up a fake player for use, placing them at the center of the specified direction and setting their equipment.
     *
     * @param player    The fake player to set up.
     * @param pos       The position of the tile entity being interacted with.
     * @param direction The direction from which the interaction is happening.
     * @param toHold    The item stack the player will be holding during the interaction.
     * @param sneaking  Whether the player should be sneaking.
     */
    public static void setupFakePlayerForUse(UsefulFakePlayer player, class_243 pos, class_2350 direction, class_1799 toHold, boolean sneaking)
    {
        player.method_31548().method_67533().set(player.method_31548().method_67532(), toHold);
        float xRot = direction == class_2350.field_11033 ? 90 : direction == class_2350.field_11036 ? -90 : 0;
        player.method_36457(xRot);
        player.method_36456(direction.method_10144());
        player.method_5847(direction.method_10144());
        class_2350.class_2351 a = direction.method_10166();
        class_2350.class_2352 ad = direction.method_10171();
        double x = a == class_2350.class_2351.field_11048 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        double y = a == class_2350.class_2351.field_11052 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        double z = a == class_2350.class_2351.field_11051 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        player.method_23327(pos.field_1352 + x, pos.field_1351 + y - player.method_23320(), pos.field_1350 + z);
        if (!toHold.method_7960())
            addAttributes(player, toHold, class_1304.field_6173);
        player.method_5660(sneaking);
    }

    /**
     * Sets up a fake player for use, placing them at the center of the specified direction and setting their equipment.
     *
     * @param player    The fake player to set up.
     * @param pos       The position of the tile entity being interacted with.
     * @param direction The direction from which the interaction is happening.
     * @param toHold    The item stack the player will be holding during the interaction.
     * @param sneaking  Whether the player should be sneaking.
     */
    public static void setupFakePlayerForUse(UsefulFakePlayer player, class_2338 pos, class_2350 direction, class_1799 toHold, boolean sneaking)
    {
        player.method_31548().method_67533().set(player.method_31548().method_67532(), toHold);
        float xRot = direction == class_2350.field_11033 ? 90 : direction == class_2350.field_11036 ? -90 : 0;
        player.method_60608(direction.method_10144(), xRot);
        player.method_5847(direction.method_10144());
        player.field_6259 = direction.method_10144();
        class_2350.class_2351 a = direction.method_10166();
        class_2350.class_2352 ad = direction.method_10171();
        double x = a == class_2350.class_2351.field_11048 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        double y = a == class_2350.class_2351.field_11052 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        double z = a == class_2350.class_2351.field_11051 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        player.method_30634(pos.method_10263() + x, pos.method_10264() + y - player.method_23320(), pos.method_10260() + z);
        if (!toHold.method_7960())
            addAttributes(player, toHold, class_1304.field_6173);
        player.method_5660(sneaking);
    }

    /**
     * Sets up a fake player for use, placing them at the center of the specified direction and setting their equipment.
     *
     * @param player    The fake player to set up.
     * @param pos       The position of the tile entity being interacted with.
     * @param direction The direction from which the interaction is happening.
     * @param toHold    The item stack the player will be holding during the interaction.
     * @param sneaking  Whether the player should be sneaking.
     */
    public static void setupFakePlayerForUse(UsefulFakePlayer player, class_2338 pos, class_2350 direction, class_243 entityPosition, class_1799 toHold, boolean sneaking)
    {
        player.method_31548().method_67533().set(player.method_31548().method_67532(), toHold);
        float xRot = direction == class_2350.field_11033 ? 90 : direction == class_2350.field_11036 ? -90 : 0;
        player.method_36457(xRot);
        player.method_36456(direction.method_10144());
        player.method_5847(direction.method_10144());
        class_2350.class_2351 a = direction.method_10166();
        class_2350.class_2352 ad = direction.method_10171();
        double x = a == class_2350.class_2351.field_11048 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        double y = a == class_2350.class_2351.field_11052 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        double z = a == class_2350.class_2351.field_11051 ? ad == class_2350.class_2352.field_11060 ? 0.95 : 0.05 : 0.5;
        player.method_23327(pos.method_10263() + x, pos.method_10264() + y - player.method_23320(), pos.method_10260() + z);
        if (!toHold.method_7960())
            addAttributes(player, toHold, class_1304.field_6173);
        player.method_5660(sneaking);

        // Calculate the rotation angles to look at the target position
        class_243 playerEyePos = new class_243(player.method_23317(), player.method_23318() + player.method_23320(), player.method_23321());
        class_243 toEntity = entityPosition.method_1020(playerEyePos).method_1029();
        float yaw = (float) Math.toDegrees(Math.atan2(toEntity.field_1350, toEntity.field_1352)) - 90.0F;
        float pitch = (float) Math.toDegrees(-Math.atan2(toEntity.field_1351, Math.sqrt(toEntity.field_1352 * toEntity.field_1352 + toEntity.field_1350 * toEntity.field_1350)));

        player.method_36456(yaw);
        player.method_5847(yaw);  // Set both the body and head rotation to the calculated yaw
        player.method_36457(pitch);
    }

    /**
     * Cleans up a fake player after it has been used.
     *
     * @param player   The fake player.
     * @param oldStack The previous item stack held by the player.
     */
    public static void cleanupFakePlayerFromUse(UsefulFakePlayer player, class_1799 oldStack)
    {
        if (!oldStack.method_7960())
            removeAttributes(player, oldStack, class_1304.field_6173);
        player.method_31548().method_67533().set(player.method_31548().method_67532(), class_1799.field_8037);
        if (!player.method_31548().method_5442()) player.method_31548().method_7388(); //Handles bucket stacks, for example
        player.method_5660(false);
        player.setReach(player.method_45325(class_5134.field_47758));
    }

    /**
     * Simulates a right click interaction with an entity in the given direction.
     *
     * @param player    The fake player.
     * @param world     The world where the interaction occurs.
     * @param entity    The entity to interact with.
     * @param clickType The type of interaction (right-click or left-click).
     * @param maxHold   The maximum time in ticks the item should be held before stopping.
     * @return The result of the interaction and the remaining item stack.
     */
    public static FakePlayerResult clickEntityInDirection(UsefulFakePlayer player, class_1937 world, class_1309 entity, int clickType, int maxHold)
    {
        class_239 toUse = rayTraceEntity(player, world, player.getReach());
        if (toUse == null) return new FakePlayerResult(class_1269.field_5814, player.method_6047());

        if (clickType == 2) {
            class_1799 itemstack = player.method_6047();
            if (itemstack.method_7960()) {
                player.method_6075();
                return new FakePlayerResult(class_1269.field_5814, player.method_6047());
            }
            if (!player.method_6115()) {
                player.method_6019(class_1268.field_5808);
            }
            player.fakeUpdateUsingItem(itemstack);
            int holdingFor = player.method_6048();
            //System.out.println("Holding For: " + holdingFor);
            if (holdingFor >= maxHold) {
                player.method_6075();
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
            }
            return new FakePlayerResult(class_1269.field_5812, player.method_6047());
        }

        if (clickType == 0) { //RightClick
            if (processUseEntity(player, world, entity, toUse, InteractionType.INTERACT_AT))
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
            else if (processUseEntity(player, world, entity, null, InteractionType.INTERACT))
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
        } else { //Left Click
            if (processUseEntity(player, world, ((class_3966) toUse).method_17782(), null, InteractionType.ATTACK))
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
        }

        return new FakePlayerResult(class_1269.field_5814, player.method_6047());
    }

    /**
     * Simulates a right or left click interaction with a block in the given direction.
     *
     * @param player    The fake player.
     * @param world     The world where the interaction occurs.
     * @param clickType The type of interaction (right-click or left-click).
     * @param maxHold   The maximum time in ticks the item should be held before stopping.
     * @return The result of the interaction and the remaining item stack.
     */
    public static FakePlayerResult clickBlockInDirection(UsefulFakePlayer player, class_1937 world, int clickType, int maxHold)
    {
        class_239 toUse = rayTraceBlock(player, world, player.getReach());
        if (toUse == null) return new FakePlayerResult(class_1269.field_5814, player.method_6047());

        class_1799 itemstack = player.method_6047();
        if (clickType == 2) {
            if (itemstack.method_7960())
            {
                player.method_6075();
                return new FakePlayerResult(class_1269.field_5814, player.method_6047());
            }
            if (!player.method_6115())
                player.method_6019(class_1268.field_5808);

            player.fakeUpdateUsingItem(itemstack);
            int holdingFor = player.method_6048();
            if (holdingFor >= maxHold)
            {
                player.method_6075();
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
            }
            return new FakePlayerResult(class_1269.field_5812, player.method_6047());
        }
        if (toUse.method_17783() == class_239.class_240.field_1332)
        {
            class_2338 blockpos = ((class_3965) toUse).method_17777();
            class_2680 state = world.method_8320(blockpos);
            if (!state.method_26215())
            {
                if (clickType == 0)
                {
                    class_1269 type = player.field_13974.method_14262(player, world, itemstack, class_1268.field_5808, (class_3965) toUse);
                    if (type == class_1269.field_5812 || type == class_1269.field_21466)
                        return new FakePlayerResult(class_1269.field_5812, player.method_6047());
                }
                else
                {
                    player.field_13974.method_14263(blockpos, class_2846.class_2847.field_12968,
                                                                         ((class_3965) toUse).method_17780(),
                                                                         player.method_51469().method_31600(), 0);
                    return new FakePlayerResult(class_1269.field_5812, player.method_6047());
                }
            }
        }

        if (toUse.method_17783() == class_239.class_240.field_1333) //Since we check for air before entering the method, there must be a block there, so try clicking it anyway
        {
            if (clickType == 0)
            {
                class_1269 type = player.field_13974.method_14262(player, world, itemstack, class_1268.field_5808, (class_3965) toUse);
                if (type == class_1269.field_5812 || type == class_1269.field_21466)
                    return new FakePlayerResult(class_1269.field_5812, player.method_6047());
            }
        }

        if (!itemstack.method_7960())
        {
            class_1269 type = player.field_13974.method_14256(player, world, itemstack, class_1268.field_5808); //Uses the item by itself
            if (type == class_1269.field_5812 || type == class_1269.field_21466)
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
        }
        return new FakePlayerResult(class_1269.field_5814, player.method_6047());
    }

    /**
     * Simulates a right click interaction with air in the given direction.
     *
     * @param player    The fake player.
     * @param world     The world where the interaction occurs.
     * @param clickType The type of interaction (right-click or left-click).
     * @param maxHold   The maximum time in ticks the item should be held before stopping.
     * @return The result of the interaction and the remaining item stack.
     */
    public static FakePlayerResult rightClickAirInDirection(UsefulFakePlayer player, class_1937 world, int clickType, int maxHold)
    {
        class_239 toUse = rayTraceBlock(player, world, player.getReach()); //Longer reach so it can connect with adjacent blocks to interact with them
        if (toUse == null) new FakePlayerResult(class_1269.field_5814, player.method_6047());

        class_1799 itemstack = player.method_6047();
        if (clickType == 2)
        {
            if (itemstack.method_7960())
            {
                player.method_6075();
                return new FakePlayerResult(class_1269.field_5814, player.method_6047());
            }
            if (!player.method_6115())
                player.method_6019(class_1268.field_5808);

            player.fakeUpdateUsingItem(itemstack);
            int holdingFor = player.method_6048();
            if (holdingFor >= maxHold)
            {
                player.method_6075();
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
            }
            return new FakePlayerResult(class_1269.field_5812, player.method_6047());
        }
        if (toUse != null && toUse.method_17783() == class_239.class_240.field_1332)
        {
            class_2338 blockpos = ((class_3965) toUse).method_17777();
            class_2680 state = world.method_8320(blockpos);
            if (!state.method_26215())
            {
                class_1269 type = player.field_13974.method_14262(player, world, itemstack, class_1268.field_5808, (class_3965) toUse);
                if (type == class_1269.field_5812 || type == class_1269.field_21466)
                    return new FakePlayerResult(class_1269.field_5812, player.method_6047());
            }
        }

        if (!itemstack.method_7960())
        {
            class_1269 type = player.field_13974.method_14256(player, world, itemstack, class_1268.field_5808); //Uses the item by itself
            if (type == class_1269.field_5812 || type == class_1269.field_21466)
                return new FakePlayerResult(class_1269.field_5812, player.method_6047());
        }
        return new FakePlayerResult(class_1269.field_5814, player.method_6047());
    }

    /**
     * Simulates an attack with whatever the fake player is holding in the given direction.
     *
     * @param player      The fake player.
     * @param world       The world where the interaction occurs.
     * @param pos         The position of the tile entity.
     * @param side        The direction to attack in.
     * @param sourceState The state of the tile entity, so we don't click ourselves.
     * @return The remaining item stack after the attack.
     */
    public static class_1799 leftClickInDirection(UsefulFakePlayer player, class_1937 world, class_2338 pos, class_2350 side, class_2680 sourceState)
    {
        class_239 toUse = rayTrace(player, world, player.getReach());
        if (toUse == null)
            return player.method_6047();

        if (toUse.method_17783() == class_239.class_240.field_1331)
        {
            if (processUseEntity(player, world, ((class_3966) toUse).method_17782(), null, InteractionType.ATTACK))
                return player.method_6047();
        }
        else if (toUse.method_17783() == class_239.class_240.field_1332)
        {
            class_2338 blockpos = ((class_3965) toUse).method_17777();
            class_2680 state = world.method_8320(blockpos);
            if (state != sourceState && !state.method_26215())
            {
                player.field_13974.method_14263(blockpos, class_2846.class_2847.field_12968,
                                                                     ((class_3965) toUse).method_17780(),
                                                                     player.method_51469().method_31600(), 0);
                return player.method_6047();
            }
        }

        if (toUse.method_17783() == class_239.class_240.field_1333)
        {
            for (int i = 1; i <= 5; i++)
            {
                class_2680 state = world.method_8320(pos.method_10079(side, i));
                if (state != sourceState && !state.method_26215())
                {
                    player.field_13974.method_14263(pos.method_10079(side, i),
                                                                         class_2846.class_2847.field_12968,
                                                                         side.method_10153(),
                                                                         player.method_51469().method_31600(), 0);
                    return player.method_6047();
                }
            }
        }

        return player.method_6047();
    }

    /**
     * Traces for an entity.
     *
     * @param player The fake player.
     * @param world  The world where the interaction occurs.
     * @return A ray trace result that will likely be of type entity, but may be type block, or null.
     */
    public static class_239 traceEntities(UsefulFakePlayer player, class_243 base, class_243 target, class_1937 world)
    {
        class_1297 pointedEntity = null;
        class_239 result = null;
        class_243 vec3d3 = null;
        class_238 search = new class_238(base.field_1352, base.field_1351, base.field_1350, target.field_1352, target.field_1351, target.field_1350).method_1009(.5, .5, .5);
        List<class_1297> list = world.method_8390(class_1297.class, search,
                                                     entity -> class_1301.field_6155.test(entity) && entity != null && entity.method_5863());
        double d2 = 5;

        for (class_1297 entity1 : list)
        {
            class_238 aabb = entity1.method_5829().method_1014(entity1.method_5871());
            Optional<class_243> optVec = aabb.method_992(base, target);

            if (aabb.method_1006(base))
            {
                if (d2 >= 0.0D)
                {
                    pointedEntity = entity1;
                    vec3d3 = optVec.orElse(base);
                    d2 = 0.0D;
                }
            }
            else if (optVec.isPresent())
            {
                double d3 = base.method_1022(optVec.get());

                if (d3 < d2 || d2 == 0.0D)
                {
                    if (entity1.method_5668() == player.method_5668())// && !entity1.canRiderInteract()) {
                    {
                        if (d2 == 0.0D)
                        {
                            pointedEntity = entity1;
                            vec3d3 = optVec.get();
                        }
                    }
                    else
                    {
                        pointedEntity = entity1;
                        vec3d3 = optVec.get();
                        d2 = d3;
                    }
                }
            }
        }

        if (pointedEntity != null && base.method_1022(vec3d3) > 5)
        {
            pointedEntity = null;
            result = class_3965.method_17778(vec3d3, null, class_2338.method_49638(vec3d3));
        }

        if (pointedEntity != null)
            result = new class_3966(pointedEntity, vec3d3);

        return result;
    }

    /**
     * Processes the use of an entity from the server side.
     *
     * @param player The fake player.
     * @param world  The world where the interaction occurs.
     * @param entity The entity to interact with.
     * @param result The actual ray trace result, only necessary if using {@link InteractionType#INTERACT_AT}
     * @param action The type of interaction to perform.
     * @return If the entity was used.
     */
    public static boolean processUseEntity(UsefulFakePlayer player, class_1937 world, class_1297 entity, @Nullable class_239 result, InteractionType action)
    {
        if (entity != null)
        {
            if (player.method_5858(entity) < 36)
            {
                if (action == InteractionType.INTERACT)
                    return player.method_7287(entity, class_1268.field_5808) == class_1269.field_5812;

                if (action == InteractionType.INTERACT_AT && result != null)
                    return entity.method_5664(player, result.method_17784(), class_1268.field_5808) == class_1269.field_5812;

                if (action == InteractionType.ATTACK)
                {
                    if (entity instanceof class_1542 || entity instanceof class_1303 || entity instanceof class_1667 || entity == player)
                        return false;
                    player.method_7324(entity);
                    return true;
                }
            }
        }
        return false;
    }

    /**
     * Performs a raytrace for what the fake player is looking at.
     *
     * @param player The fake player.
     * @param world  The world where the interaction occurs.
     * @return A ray trace result that could be of type block, entity, or miss.
     */
    public static class_239 rayTrace(UsefulFakePlayer player, class_1937 world, double reachDist)
    {
        class_243 base = new class_243(player.method_23317(), player.method_23320(), player.method_23321());
        class_243 look = player.method_5720();
        class_243 target = base.method_1031(look.field_1352 * reachDist, look.field_1351 * reachDist, look.field_1350 * reachDist);
        class_239 trace = world.method_17742(new class_3959(base, target,
                                                           class_3959.class_3960.field_17559,
                                                           class_3959.class_242.field_1345, player));
        class_239 traceEntity = traceEntities(player, base, target, world);
        class_239 toUse = trace == null ? traceEntity : trace;

        if (trace != null && traceEntity != null) {
            double d1 = trace.method_17784().method_1022(base);
            double d2 = traceEntity.method_17784().method_1022(base);
            toUse = traceEntity.method_17783() == class_239.class_240.field_1331 && d1 > d2 ? traceEntity : trace;
        }

        return toUse;
    }

    /**
     * Performs a block raytrace for what the fake player is looking at.
     *
     * @param player The fake player.
     * @param world  The world where the interaction occurs.
     * @return A ray trace result that will be of type block or miss.
     */
    public static class_239 rayTraceBlock(UsefulFakePlayer player, class_1937 world, double reachDist)
    {
        class_243 base = new class_243(player.method_23317(), player.method_23320(), player.method_23321());
        class_243 look = player.method_5720();
        class_243 target = base.method_1031(look.field_1352 * reachDist, look.field_1351 * reachDist, look.field_1350 * reachDist);

        return world.method_17742(new class_3959(base, target,
                                                class_3959.class_3960.field_17559,
                                                class_3959.class_242.field_1345, player));
    }

    /**
     * Performs an entity raytrace for what the fake player is looking at.
     *
     * @param player The fake player.
     * @param world  The world where the interaction occurs.
     * @return A ray trace result that will be of type entity or miss.
     */
    public static class_239 rayTraceEntity(UsefulFakePlayer player, class_1937 world, double reachDist)
    {
        class_243 base = new class_243(player.method_23317(), player.method_23320(), player.method_23321());
        class_243 look = player.method_5720();
        class_243 target = base.method_1031(look.field_1352 * reachDist, look.field_1351 * reachDist, look.field_1350 * reachDist);

        return traceEntities(player, base, target, world);
    }

    /**
     * Enumeration of interaction types.
     */
    public enum InteractionType {
        INTERACT,
        INTERACT_AT,
        ATTACK
    }
}