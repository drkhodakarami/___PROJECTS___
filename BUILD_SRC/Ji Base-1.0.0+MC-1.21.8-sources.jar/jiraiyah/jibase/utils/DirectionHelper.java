/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.utils;

import jiraiyah.jibase.annotations.CreatedAt;
import jiraiyah.jibase.annotations.Developer;
import jiraiyah.jibase.annotations.Repository;
import jiraiyah.jibase.annotations.Youtube;
import net.minecraft.class_1657;
import net.minecraft.class_2350;
import net.minecraft.class_243;

/**
 * Provides utility methods for working with directions in Minecraft.
 */
@SuppressWarnings("unused")
@Developer("Direwolf20")
@CreatedAt("2025-04-18")
@Repository("https://github.com/Direwolf20-MC/JustDireThings")
@Youtube("https://www.youtube.com/@direwolf20")
public class DirectionHelper
{
    /**
     * Determines the primary direction based on a vector.
     *
     * @param vec The vector to determine the direction from.
     * @return The primary direction.
     */
    public static class_2350 getPrimaryDirection(class_243 vec)
    {
        double absX = Math.abs(vec.field_1352);
        double absY = Math.abs(vec.field_1351);
        double absZ = Math.abs(vec.field_1350);

        // Determine the largest magnitude component
        if (absX > absY && absX > absZ)
            return vec.field_1352 > 0 ? class_2350.field_11034 : class_2350.field_11039;
        if (absY > absX && absY > absZ)
            return vec.field_1351 > 0 ? class_2350.field_11036 : class_2350.field_11033;
        return vec.field_1350 > 0 ? class_2350.field_11035 : class_2350.field_11043;
    }

    /**
     * Determines the facing direction for a player based on their yaw and pitch.
     *
     * @param player The player to determine the facing direction for.
     * @return The facing direction.
     */
    public static class_2350 getFacingDirection(class_1657 player)
    {
        float yaw = player.method_36454();
        float pitch = player.method_36455();

        // Convert yaw to horizontal direction
        class_2350 horizontalDirection = class_2350.method_10150(yaw);

        // Adjust for vertical direction if necessary (e.g., UP or DOWN)
        if (pitch < -45)
            return class_2350.field_11036;
        if (pitch > 45)
            return class_2350.field_11033;
        return horizontalDirection;
    }
}