/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.utils;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.exceptions.Exceptions;
import net.minecraft.class_10355;
import net.minecraft.class_1299;
import net.minecraft.class_1320;
import net.minecraft.class_1761;
import net.minecraft.class_179;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1842;
import net.minecraft.class_1865;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2378;
import net.minecraft.class_2591;
import net.minecraft.class_2806;
import net.minecraft.class_2960;
import net.minecraft.class_3611;
import net.minecraft.class_3852;
import net.minecraft.class_3854;
import net.minecraft.class_3917;
import net.minecraft.class_3956;
import net.minecraft.class_5321;
import net.minecraft.class_5864;
import net.minecraft.class_6018;
import net.minecraft.class_6862;
import net.minecraft.class_7923;
import net.minecraft.class_9331;
import net.minecraft.class_9428;
import net.minecraft.class_9766;
import org.jetbrains.annotations.NotNull;
import java.util.List;
import java.util.Objects;

/**
 * Provides utility methods for working with various Minecraft registries and identifiers.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@ModifiedAt("2025-04-23")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class BaseHelper
{
    /**
     * Private constructor to prevent instantiation.
     */
    public BaseHelper()
    {
        Exceptions.throwCtorAssertion();
    }

    /**
     * Creates a new Minecraft identifier with the given mod ID and path.
     *
     * @param modID The mod ID.
     * @param path  The path for the identifier.
     * @return The created Identifier.
     */
    public static class_2960 identifier(String modID, @NotNull String path)
    {
        return class_2960.method_60655(modID, path);
    }

    /**
     * Creates a new registry key with the given name and registry type.
     *
     * @param <T>          The type of the registry.
     * @param modID        The mod ID.
     * @param name         The name for the registry key.
     * @param registryKey  The registry key for the target registry.
     * @return The created RegistryKey.
     */
    public static <T> class_5321<T> getKey(String modID, String name, class_5321<? extends class_2378<T>> registryKey)
    {
        return class_5321.method_29179(registryKey, identifier(modID, name));
    }

    /**
     * Generates a tag check string for the given item tag.
     *
     * @param tag The item tag key.
     * @return A tag check string.
     */
    public static @NotNull String hasTag(@NotNull class_6862<class_1792> tag)
    {
        return "has_" + tag.comp_327().toString();
    }

    /**
     * Retrieves the registry name for a given fluid.
     *
     * @param fluid The fluid to get the registry name for.
     * @return The registry name of the fluid.
     */
    public static String getRegistryName(class_3611 fluid)
    {
        return class_7923.field_41173.method_10221(fluid).method_12832();
    }

    /**
     * Retrieves the registry name for a given item.
     *
     * @param item The item to get the registry name for.
     * @return The registry name of the item.
     */
    public static String getRegistryName(class_1792 item)
    {
        return class_7923.field_41178.method_10221(item).method_12832();
    }

    /**
     * Retrieves the registry name for a given item stack.
     *
     * @param stack The item stack to get the registry name for.
     * @return The registry name of the item in the stack.
     */
    public static String getRegistryName(class_1799 stack)
    {
        return class_7923.field_41178.method_10221(stack.method_7909()).method_12832();
    }

    /**
     * Retrieves the registry name for a given block.
     *
     * @param block The block to get the registry name for.
     * @return The registry name of the block.
     */
    public static String getRegistryName(class_2248 block)
    {
        return class_7923.field_41175.method_10221(block).method_12832();
    }

    /**
     * Retrieves the registry name for a given entity type.
     *
     * @param entityType The entity type to get the registry name for.
     * @return The registry name of the entity type.
     */
    public static String getRegistryName(class_1299<?> entityType)
    {
        return class_7923.field_41177.method_10221(entityType).method_12832();
    }

    /**
     * Retrieves the registry name for a given potion.
     *
     * @param potion The potion to get the registry name for.
     * @return The registry name of the potion.
     */
    public static String getRegistryName(class_1842 potion)
    {
        return Objects.requireNonNull(class_7923.field_41179.method_10221(potion)).method_12832();
    }

    /**
     * Retrieves the registry name for a given block entity type.
     *
     * @param blockEntityType The block entity type to get the registry name for.
     * @return The registry name of the block entity type.
     */
    public static String getRegistryName(class_2591<?> blockEntityType)
    {
        return Objects.requireNonNull(class_7923.field_41181.method_10221(blockEntityType)).method_12832();
    }

    /**
     * Retrieves the registry name for a given custom stat identifier.
     *
     * @param identifier The custom stat identifier to get the registry name for.
     * @return The registry name of the custom stat.
     */
    public static String getRegistryName(class_2960 identifier)
    {
        return Objects.requireNonNull(class_7923.field_41183.method_10221(identifier)).method_12832();
    }

    /**
     * Retrieves the registry name for a given chunk status.
     *
     * @param chunkStatus The chunk status to get the registry name for.
     * @return The registry name of the chunk status.
     */
    public static String getRegistryName(class_2806 chunkStatus)
    {
        return class_7923.field_41184.method_10221(chunkStatus).method_12832();
    }

    /**
     * Retrieves the registry name for a given entity attribute.
     *
     * @param entityAttribute The entity attribute to get the registry name for.
     * @return The registry name of the entity attribute.
     */
    public static String getRegistryName(class_1320 entityAttribute)
    {
        return Objects.requireNonNull(class_7923.field_41190.method_10221(entityAttribute)).method_12832();
    }

    /**
     * Retrieves the registry name for a given screen handler type.
     *
     * @param screenHandlerType The screen handler type to get the registry name for.
     * @return The registry name of the screen handler type.
     */
    public static String getRegistryName(class_3917<?> screenHandlerType)
    {
        return Objects.requireNonNull(class_7923.field_41187.method_10221(screenHandlerType)).method_12832();
    }

    /**
     * Retrieves the registry name for a given recipe type.
     *
     * @param recipeType The recipe type to get the registry name for.
     * @return The registry name of the recipe type.
     */
    public static String getRegistryName(class_3956<?> recipeType)
    {
        return Objects.requireNonNull(class_7923.field_41188.method_10221(recipeType)).method_12832();
    }

    /**
     * Retrieves the registry name for a given recipe serializer.
     *
     * @param recipeSerializer The recipe serializer to get the registry name for.
     * @return The registry name of the recipe serializer.
     */
    public static String getRegistryName(class_1865<?> recipeSerializer)
    {
        return Objects.requireNonNull(class_7923.field_41189.method_10221(recipeSerializer)).method_12832();
    }

    /**
     * Retrieves the registry name for a given villager type.
     *
     * @param villagerType The villager type to get the registry name for.
     * @return The registry name of the villager type.
     */
    public static String getRegistryName(class_3854 villagerType)
    {
        return class_7923.field_41194.method_10221(villagerType).method_12832();
    }

    /**
     * Retrieves the registry name for a given villager profession.
     *
     * @param villagerProfession The villager profession to get the registry name for.
     * @return The registry name of the villager profession.
     */
    public static String getRegistryName(class_3852 villagerProfession)
    {
        return class_7923.field_41195.method_10221(villagerProfession).method_12832();
    }

    /**
     * Retrieves the registry name for a given float provider type.
     *
     * @param floatProviderType The float provider type to get the registry name for.
     * @return The registry name of the float provider type.
     */
    public static String getRegistryName(class_5864<?> floatProviderType)
    {
        return Objects.requireNonNull(class_7923.field_41139.method_10221(floatProviderType)).method_12832();
    }

    /**
     * Retrieves the registry name for a given int provider type.
     *
     * @param intProviderType The int provider type to get the registry name for.
     * @return The registry name of the int provider type.
     */
    public static String getRegistryName(class_6018<?> intProviderType)
    {
        return Objects.requireNonNull(class_7923.field_41140.method_10221(intProviderType)).method_12832();
    }

    /**
     * Retrieves the registry name for a given decorated pot pattern.
     *
     * @param decoratedPotPattern The decorated pot pattern to get the registry name for.
     * @return The registry name of the decorated pot pattern.
     */
    public static String getRegistryName(class_9766 decoratedPotPattern)
    {
        return Objects.requireNonNull(class_7923.field_42940.method_10221(decoratedPotPattern)).method_12832();
    }

    /**
     * Retrieves the registry name for a given item group.
     *
     * @param itemGroup The item group to get the registry name for.
     * @return The registry name of the item group.
     */
    public static String getRegistryName(class_1761 itemGroup)
    {
        return Objects.requireNonNull(class_7923.field_44687.method_10221(itemGroup)).method_12832();
    }

    /**
     * Retrieves the registry name for a given criterion.
     *
     * @param criterion The criterion to get the registry name for.
     * @return The registry name of the criterion.
     */
    public static String getRegistryName(class_179<?> criterion)
    {
        return Objects.requireNonNull(class_7923.field_47496.method_10221(criterion)).method_12832();
    }

    /**
     * Retrieves the registry name for a given data component type or enchantment effect component type.
     *
     * @param componentType The component type to get the registry name for.
     * @param isEnchantment Whether this is an enchantment effect component type.
     * @return The registry name of the component type.
     */
    public static String getRegistryName(class_9331<?> componentType, boolean isEnchantment)
    {
        return isEnchantment
               ? Objects.requireNonNull(class_7923.field_51832.method_10221(componentType)).method_12832()
               : Objects.requireNonNull(class_7923.field_49658.method_10221(componentType)).method_12832();
    }

    /**
     * Retrieves the registry name for a given map decoration type.
     *
     * @param mapDecorationType The map decoration type to get the registry name for.
     * @return The registry name of the map decoration type.
     */
    public static String getRegistryName(class_9428 mapDecorationType)
    {
        return Objects.requireNonNull(class_7923.field_50078.method_10221(mapDecorationType)).method_12832();
    }

    /**
     * Retrieves the registry name for a given recipe book category.
     *
     * @param recipeBookCategory The recipe book category to get the registry name for.
     * @return The registry name of the recipe book category.
     */
    public static String getRegistryName(class_10355 recipeBookCategory)
    {
        return Objects.requireNonNull(class_7923.field_54927.method_10221(recipeBookCategory)).method_12832();
    }

    /**
     * Retrieves a list of items that are in the given item tag.
     *
     * @param tagKey The item tag key to get the items for.
     * @return A list of items in the tag.
     */
    public static List<class_1792> getItemsWithTag(class_6862<class_1792> tagKey)
    {
        return class_7923.field_41178.method_10220()
                              .filter(item -> class_7923.field_41178.method_47983(item).method_40220(tagKey))
                              .toList();
    }

    /**
     * Retrieves a list of blocks that are in the given block tag.
     *
     * @param tagKey The block tag key to get the blocks for.
     * @return A list of blocks in the tag.
     */
    public static List<class_2248> getBlocksWithTag(class_6862<class_2248> tagKey)
    {
        return class_7923.field_41175.method_10220()
                               .filter(block -> class_7923.field_41175.method_47983(block).method_40220(tagKey))
                               .toList();
    }

    /**
     * Retrieves a list of block entity types that are in the given block entity type tag.
     *
     * @param tagKey The block entity type tag key to get the block entity types for.
     * @return A list of block entity types in the tag.
     */
    public static List<class_2591<?>> getBlockEntitiesWithTag(class_6862<class_2591<?>> tagKey)
    {
        return class_7923.field_41181.method_10220()
                                           .filter(blockEntityType -> class_7923.field_41181.method_47983(blockEntityType).method_40220(tagKey))
                                           .toList();
    }

    /**
     * Retrieves a list of entity types that are in the given entity type tag.
     *
     * @param tagKey The entity type tag key to get the entity types for.
     * @return A list of entity types in the tag.
     */
    public static List<class_1299<?>> getEntitiesWithTag(class_6862<class_1299<?>> tagKey)
    {
        return class_7923.field_41177.method_10220()
                                     .filter(entityType -> class_7923.field_41177.method_47983(entityType).method_40220(tagKey))
                                     .toList();
    }

    /**
     * Retrieves the dimension identifier for the given world.
     *
     * @param world The world to get the dimension identifier for.
     * @return The dimension identifier.
     */
    public static class_2960 getDimensionId(class_1937 world)
    {
        return world.method_27983().method_29177();
    }

    /**
     * Retrieves the dimension name for the given world.
     *
     * @param world The world to get the dimension name for.
     * @return The dimension name.
     */
    public static String getDimensionName(class_1937 world)
    {
        return getDimensionId(world).toString();
    }

    /**
     * Retrieves a cleaned, readable version of the dimension name.
     *
     * @param world The world to get the clean dimension name for.
     * @return A cleaned dimension name.
     */
    public static String getDimensionNameClean(class_1937 world)
    {
        return getDimensionNameClean(getDimensionName(world));
    }

    /**
     * Retrieves a cleaned, readable version of the dimension name from a string.
     *
     * @param dimensionName The dimension name as a string.
     * @return A cleaned dimension name.
     */
    public static String getDimensionNameClean(String dimensionName)
    {
        return dimensionName.substring(dimensionName.indexOf(':') + 1).replace('_', ' ');
    }
}