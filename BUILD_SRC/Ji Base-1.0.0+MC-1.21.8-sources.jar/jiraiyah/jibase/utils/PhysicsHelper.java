/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.utils;

import jiraiyah.jibase.annotations.CreatedAt;
import jiraiyah.jibase.annotations.Developer;
import jiraiyah.jibase.annotations.Repository;
import jiraiyah.jibase.annotations.Youtube;
import net.minecraft.class_1297;
import net.minecraft.class_1657;
import net.minecraft.class_238;
import net.minecraft.class_239;
import net.minecraft.class_243;
import net.minecraft.class_3959;
import net.minecraft.class_3965;
import net.minecraft.class_3966;
import java.util.Optional;

/**
 * Provides utility methods for physics-related operations in Minecraft.
 */
@SuppressWarnings("unused")
@Developer("Direwolf20")
@CreatedAt("2025-04-18")
@Repository("https://github.com/Direwolf20-MC/JustDireThings")
@Youtube("https://www.youtube.com/@direwolf20")
public class PhysicsHelper
{
    /**
     * Gets the block hit result for a player's current look direction.
     *
     * @param player The player entity to get the hit result for.
     * @return The block hit result.
     */
    public static class_3965 getHitResult(class_1657 player)
    {
        var playerLook = new class_243(player.method_23317(), player.method_23318() + player.method_23320(), player.method_23321());
        var lookVec = player.method_5836(1.0F);
        var reach = player.method_55754();
        var endLook = playerLook.method_1031(lookVec.field_1352 * reach, lookVec.field_1351 * reach, lookVec.field_1350 * reach);
        return player.method_37908()
                     .method_17742(new class_3959(playerLook, endLook,
                                                 class_3959.class_3960.field_17558,
                                             class_3959.class_242.field_1348,
                                                    player));
    }

    /**
     * Gets the entity that is being looked at by a player within a specified maximum distance.
     *
     * @param player The player entity to get the entity look result for.
     * @param maxDistance The maximum distance to check for entities.
     * @return The entity being looked at, or null if no entity is found.
     */
    public static class_1297 getEntityLookedAt(class_1657 player, double maxDistance)
    {
        class_243 eyePosition = player.method_5836(1.0F);
        class_243 lookVector = player.method_5828(1.0F).method_1021(maxDistance);
        class_243 endPosition = eyePosition.method_1019(lookVector);

        // Perform ray trace for entities
        class_239 hitResult = player.method_37908()
                                    .method_17742(new class_3959(eyePosition, endPosition,
                                         class_3959.class_3960.field_17559,
                                     class_3959.class_242.field_1348,
                                            player));

        if (hitResult.method_17783() != class_239.class_240.field_1333)
            endPosition = hitResult.method_17784();

        class_3966 entityHitResult = rayTraceEntities(player, eyePosition, endPosition,
                                                           player.method_5829()
                                                                   .method_18804(lookVector)
                                                                   .method_1009(1.0D, 1.0D, 1.0D), maxDistance);

        if (entityHitResult != null)
            return entityHitResult.method_17782();

        return null;
    }

    /**
     * Performs a ray trace for entities within the given bounds and returns the closest one.
     *
     * @param player The player entity performing the ray trace.
     * @param start The starting position of the ray.
     * @param end The ending position of the ray.
     * @param boundingBox The bounding box to search within.
     * @param maxDistance The maximum distance to check for entities.
     * @return The closest entity hit by the ray, or null if no entity is found.
     */
    private static class_3966 rayTraceEntities(class_1657 player, class_243 start, class_243 end, class_238 boundingBox, double maxDistance)
    {
        double closestDistance = maxDistance;
        class_1297 closestEntity = null;
        class_243 hitLocation = null;

        for (class_1297 entity : player.method_37908().method_8333(player, boundingBox, e -> e != player && e.method_5863()))
        {
            class_238 entityBoundingBox = entity.method_5829().method_1014(entity.method_5871());
            Optional<class_243> optHitVec = entityBoundingBox.method_992(start, end);

            if (entityBoundingBox.method_1006(start))
            {
                if (closestDistance >= 0.0D)
                {
                    closestEntity = entity;
                    hitLocation = optHitVec.orElse(start);
                    closestDistance = 0.0D;
                }
            }
            else if (optHitVec.isPresent())
            {
                class_243 hitVec = optHitVec.get();
                double distanceToHitVec = start.method_1022(hitVec);

                if (distanceToHitVec < closestDistance || closestDistance == 0.0D)
                {
                    if (entity.method_5668() == player.method_5668())
                    {// && !entity.canRiderInteract()) {
                        if (closestDistance == 0.0D)
                        {
                            closestEntity = entity;
                            hitLocation = hitVec;
                        }
                    }
                    else
                    {
                        closestEntity = entity;
                        hitLocation = hitVec;
                        closestDistance = distanceToHitVec;
                    }
                }
            }
        }

        return closestEntity == null ? null : new class_3966(closestEntity, hitLocation);
    }
}