/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.enumerations;

import com.google.common.collect.BiMap;
import com.google.common.collect.HashBiMap;
import jiraiyah.jibase.annotations.*;
import net.minecraft.class_156;
import net.minecraft.class_2350;

/**
 * Enum representing mapped directions.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public enum MappedDirection
{
    /**
     * Represents the direction down.
     */
    DOWN,

    /**
     * Represents the direction up.
     */
    UP,

    /**
     * Represents the direction north.
     */
    NORTH,

    /**
     * Represents the direction south.
     */
    SOUTH,

    /**
     * Represents the direction west.
     */
    WEST,

    /**
     * Represents the direction east.
     */
    EAST,

    /**
     * Represents no specific direction.
     */
    NONE;

    /**
     * A bi-directional map between Minecraft Direction and MappedDirection for easy conversion.
     */
    static final BiMap<class_2350, MappedDirection> biMap =
            class_156.method_654(HashBiMap.create(),
                      map ->
                      {
                          map.put(null, MappedDirection.NONE);
                          map.put(class_2350.field_11033, MappedDirection.DOWN);
                          map.put(class_2350.field_11036, MappedDirection.UP);
                          map.put(class_2350.field_11043, MappedDirection.NORTH);
                          map.put(class_2350.field_11035, MappedDirection.SOUTH);
                          map.put(class_2350.field_11034, MappedDirection.EAST);
                          map.put(class_2350.field_11039, MappedDirection.WEST);
                      });

    /**
     * Converts a Minecraft Direction to its corresponding MappedDirection.
     *
     * @param direction The Minecraft Direction to convert.
     * @return The corresponding MappedDirection.
     */
    public static MappedDirection fromDirection(class_2350 direction)
    {
        return biMap.get(direction);
    }

    /**
     * Converts an MappedDirection to its corresponding Minecraft Direction.
     *
     * @param direction The MappedDirection to convert.
     * @return The corresponding Minecraft Direction.
     */
    public static class_2350 toDirection(MappedDirection direction)
    {
        return biMap.inverse().get(direction);
    }
}