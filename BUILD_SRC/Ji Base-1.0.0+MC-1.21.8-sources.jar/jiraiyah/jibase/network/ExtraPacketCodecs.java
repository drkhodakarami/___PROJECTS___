/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.network;

import io.netty.buffer.ByteBuf;
import jiraiyah.jibase.annotations.*;
import net.minecraft.class_5861;
import net.minecraft.class_5862;
import net.minecraft.class_5863;
import net.minecraft.class_5864;
import net.minecraft.class_5865;
import net.minecraft.class_5866;
import net.minecraft.class_6010;
import net.minecraft.class_6012;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6018;
import net.minecraft.class_6019;
import net.minecraft.class_6333;
import net.minecraft.class_6334;
import net.minecraft.class_6642;
import net.minecraft.class_6728;
import net.minecraft.class_7923;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.util.math.floatprovider.*;
import net.minecraft.util.math.intprovider.*;
import java.util.HashMap;
import java.util.Map;

/**
 * Provides packet codecs for various integer and float providers used in the game.
 */
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")

@SuppressWarnings("unchecked")
public class ExtraPacketCodecs
{
    /**
     * A map of integer provider types to their corresponding packet codecs.
     */
    private static final Map<class_6018<?>, class_9139<class_9129, ? extends class_6017>> INT_PROVIDER_CODECS = new HashMap<>();

    /**
     * A map of float provider types to their corresponding packet codecs.
     */
    private static final Map<class_5864<?>, class_9139<class_9129, ? extends class_5863>> FLOAT_PROVIDER_CODECS = new HashMap<>();

    // Static block to register default packet codecs for integer and float providers.
    static
    {
        registerDefaults();
    }

    /**
     * Registers a packet codec for an integer provider type.
     *
     * @param providerType the integer provider type
     * @param codec        the packet codec to register
     */
    public static <T extends class_6017> void registerIntProvider(class_6018<T> providerType, class_9139<class_9129, T> codec)
    {
        INT_PROVIDER_CODECS.put(providerType, codec);
    }

    /**
     * Registers a packet codec for a float provider type.
     *
     * @param providerType the float provider type
     * @param codec        the packet codec to register
     */
    public static <T extends class_5863> void registerFloatProvider(class_5864<T> providerType, class_9139<class_9129, T> codec)
    {
        FLOAT_PROVIDER_CODECS.put(providerType, codec);
    }

    /**
     * Retrieves the packet codec for a given integer provider type.
     *
     * @param providerType the integer provider type
     * @return the corresponding packet codec
     */
    public static class_9139<class_9129, ? extends class_6017> getIntProviderCodec(class_6018<?> providerType)
    {
        return INT_PROVIDER_CODECS.get(providerType);
    }

    /**
     * Retrieves the packet codec for a given float provider type.
     *
     * @param providerType the float provider type
     * @return the corresponding packet codec
     */
    public static class_9139<class_9129, ? extends class_5863> getFloatProviderCodec(class_5864<?> providerType)
    {
        return FLOAT_PROVIDER_CODECS.get(providerType);
    }

    /**
     * Encodes an integer provider to a byte buffer.
     *
     * @param buf      the byte buffer to encode into
     * @param intProvider the integer provider to encode
     */
    public static <T extends class_6017> void encode(ByteBuf buf, T intProvider)
    {
        class_9139<class_9129, T> codec = (class_9139<class_9129, T>) getIntProviderCodec(intProvider.method_35012());
        codec.encode((class_9129) buf, intProvider);
    }

    /**
     * Decodes an integer provider from a byte buffer.
     *
     * @param buf       the byte buffer to decode from
     * @param providerType the type of the integer provider
     * @return the decoded integer provider
     */
    public static  <T extends class_6017> T decode(ByteBuf buf, class_6018<T> providerType)
    {
        class_9139<class_9129, T> codec = (class_9139<class_9129, T>) getIntProviderCodec(providerType);
        return codec.decode((class_9129) buf);
    }

    /**
     * Encodes a float provider to a byte buffer.
     *
     * @param buf      the byte buffer to encode into
     * @param floatProvider the float provider to encode
     */
    public static <T extends class_5863> void encode(ByteBuf buf, T floatProvider)
    {
        class_9139<class_9129, T> codec = (class_9139<class_9129, T>) getFloatProviderCodec(floatProvider.method_33923());
        codec.encode((class_9129) buf, floatProvider);
    }

    /**
     * Decodes a float provider from a byte buffer.
     *
     * @param buf       the byte buffer to decode from
     * @param providerType the type of the float provider
     * @return the decoded float provider
     */
    public static  <T extends class_5863> T decode(ByteBuf buf, class_5864<T> providerType)
    {
        class_9139<class_9129, T> codec = (class_9139<class_9129, T>) getFloatProviderCodec(providerType);
        return codec.decode((class_9129) buf);
    }

    /**
     * Registers default packet codecs for integer and float providers.
     */
    public static void registerDefaults()
    {
        registerIntProvider(class_6018.field_29947,
                            class_9139.method_56437(
                                    (buf, intProvider) -> buf.method_53002(intProvider.method_34997()),
                                    buf -> class_6016.method_34998(buf.readInt())
                            ));

        registerIntProvider(class_6018.field_29948,
                            class_9139.method_56437(
                                    (buf, intProvider) ->
                                    {
                                        buf.method_53002(intProvider.method_35009());
                                        buf.method_53002(intProvider.method_35011());
                                    },
                                    buf -> class_6019.method_35017(buf.readInt(), buf.readInt())
                            ));

        registerIntProvider(class_6018.field_33452,
                            class_9139.method_56437(
                                    (buf, intProvider) ->
                                    {
                                        buf.method_53002(intProvider.method_35009());
                                        buf.method_53002(intProvider.method_35011());
                                    },
                                    buf -> class_6333.method_36249(buf.readInt(), buf.readInt())
                            ));

        registerIntProvider(class_6018.field_33453,
                            class_9139.method_56437(
                                    (buf, intProvider) ->
                                    {
                                        class_6018<?> type = class_7923.field_41140.method_63535(buf.method_10810());
                                        class_9139<class_9129, class_6017> codec = (class_9139<class_9129, class_6017>) getIntProviderCodec(type);
                                        codec.encode(buf, intProvider.field_33447);
                                        buf.method_53002(intProvider.method_35009());
                                        buf.method_53002(intProvider.method_35011());
                                    },
                                    buf -> class_6334.method_36255(
                                            getIntProviderCodec(class_6018.field_29947).decode(buf),
                                                buf.readInt(), buf.readInt())
                            ));

        registerIntProvider(class_6018.field_35034,
                            class_9139.method_56437(
                                    (buf, value) ->
                                    {
                                        class_9139<class_9129, ? extends class_6017> codec = getIntProviderCodec(value.method_35012());
                                        class_6012<class_6017> entries = value.field_35036;
                                        class_9139<class_9129, class_6012<class_6017>> entriesCodec = weightedListCodec((class_9139<class_9129, class_6017>) codec);
                                        entriesCodec.encode(buf, entries);
                                    },
                                    buf ->
                                    {
                                        class_9139<class_9129, ? extends class_6017> codec = getIntProviderCodec(class_6018.field_29947);
                                        class_6012<class_6017> entries = weightedListCodec((class_9139<class_9129, class_6017>) codec).decode(buf);
                                        return new class_6642(entries);
                                    }
                            ));

        registerIntProvider(class_6018.field_35357,
                            class_9139.method_56437(
                                    (buf, intProvider) ->
                                    {
                                        buf.method_52941(intProvider.field_35353);
                                        buf.method_52941(intProvider.field_35354);
                                        buf.method_53002(intProvider.method_35009());
                                        buf.method_53002(intProvider.method_35011());
                                    },
                                    buf -> class_6728.method_39156(buf.readFloat(),buf.readFloat(),
                                                                           buf.readInt(), buf.readInt())
                            ));

        registerFloatProvider(class_5864.field_29008,
                              class_9139.method_56437(
                                      (buf, floatProvider) -> buf.method_52941(floatProvider.method_33914()),
                                      buf -> class_5862.method_33908(buf.readFloat())
                              ));

        registerFloatProvider(class_5864.field_29009,
                              class_9139.method_56437(
                                      (buf, floatProvider) ->
                                      {
                                          buf.method_52941(floatProvider.method_33915());
                                          buf.method_52941(floatProvider.method_33921());
                                      },
                                      buf -> class_5866.method_33934(buf.readFloat(), buf.readFloat())
                              ));

        registerFloatProvider(class_5864.field_29010,
                            class_9139.method_56437(
                                    (buf, floatProvider) ->
                                    {
                                        buf.method_52941(floatProvider.field_28999);
                                        buf.method_52941(floatProvider.field_29000);
                                        buf.method_52941(floatProvider.method_33915());
                                        buf.method_52941(floatProvider.method_33921());
                                    },
                                    buf -> class_5861.method_33900(buf.readFloat(), buf.readFloat(),
                                                                         buf.readFloat(), buf.readFloat())
                            ));

        registerFloatProvider(class_5864.field_29011,
                              class_9139.method_56437(
                                      (buf, floatProvider) ->
                                      {
                                          buf.method_52941(floatProvider.method_33915());
                                          buf.method_52941(floatProvider.method_33921());
                                          buf.method_52941(floatProvider.field_29015);
                                      },
                                      buf -> class_5865.method_33926(buf.readFloat(), buf.readFloat(),
                                                                               buf.readFloat())
                              ));
    }

    /**
     * Creates a packet codec for encoding and decoding weight lists.
     *
     * @param elementCodec the codec for encoding and decoding individual elements in the weight list
     * @param <B>          the type of byte buffer being used
     * @param <E>          the type of elements in the weight list
     * @return a packet codec for encoding and decoding weight lists
     */
    public static <B extends ByteBuf, E> class_9139<B, class_6012<E>> weightedListCodec(class_9139<B, E> elementCodec) {
        return class_9139.<B, class_6010<E>, E, Integer>method_56435(
                elementCodec, class_6010::comp_2542,
                class_9135.field_48550, class_6010::comp_2543,
                class_6010::new
        ).method_56433(class_9135.method_56363()).method_56432(class_6012::new, class_6012::method_34994);
    }
}