/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.records;

import com.mojang.serialization.Codec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.utils.MathHelper;
import net.minecraft.class_10302;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_1856;
import net.minecraft.class_6885;
import net.minecraft.class_7924;
import net.minecraft.class_9129;
import net.minecraft.class_9135;
import net.minecraft.class_9139;
import net.minecraft.class_9326;
import java.util.Arrays;
import java.util.List;
import java.util.function.Predicate;

/**
 * Represents a configured ingredient, combining an item list and stack data payload.
 */
@SuppressWarnings("unused")
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")

public record ConfiguredIngredient(class_6885<class_1792> entries, StackDataPayload stackData)
{
    /**
     * The codec used to serialize and deserialize the ConfiguredIngredient.
     */
    public static final Codec<ConfiguredIngredient> CODEC = Codec.lazyInitialized(() -> RecordCodecBuilder.create(
            inst -> inst.group(
                    class_1856.field_52596.fieldOf("ingredients").forGetter(ConfiguredIngredient::entries),
                    StackDataPayload.CODEC.optionalFieldOf("data", StackDataPayload.EMPTY).forGetter(ConfiguredIngredient::stackData)
            ).apply(inst, ConfiguredIngredient::new)
    ));

    /**
     * The packet codec used to send and receive the ConfiguredIngredient.
     */
    public static final class_9139<class_9129, ConfiguredIngredient> PACKET_CODEC = class_9139.method_56435(
            class_9135.method_58001(class_7924.field_41197), ConfiguredIngredient::entries,
            StackDataPayload.PACKET_CODEC, ConfiguredIngredient::stackData,
            ConfiguredIngredient::new
    );

    /**
     * An empty instance of ConfiguredIngredient.
     */
    public static final ConfiguredIngredient EMPTY = new ConfiguredIngredient(class_6885.method_40246(), StackDataPayload.EMPTY);

    /**
     * Creates a new ConfiguredIngredient with the given items and default stack data (count 1).
     *
     * @param entries the items to include in the ingredient
     */
    public ConfiguredIngredient(class_6885<class_1792> entries)
    {
        this(entries, StackDataPayload.create(1));
    }

    /**
     * Creates a new ConfiguredIngredient with the given items and specified count.
     *
     * @param entries the items to include in the ingredient
     * @param count   the count of each item
     */
    public ConfiguredIngredient(class_6885<class_1792> entries, int count)
    {
        this(entries, StackDataPayload.create(count));
    }

    /**
     * Creates a new ConfiguredIngredient with the given items and default stack data (count 1).
     *
     * @param items the items to include in the ingredient
     */
    @SuppressWarnings("deprecation")
    public ConfiguredIngredient(int count, class_1792... items)
    {
        this(class_6885.method_40242(Arrays.stream(items).map(class_1792::method_40131).toList()), StackDataPayload.create(count));
    }

    /**
     * Creates a new ConfiguredIngredient with the given items and default stack data (count 1).
     *
     * @param items the items to include in the ingredient
     */
    @SuppressWarnings("deprecation")
    public ConfiguredIngredient(class_1792... items)
    {
        this(class_6885.method_40242(Arrays.stream(items).map(class_1792::method_40131).toList()), StackDataPayload.create(1));
    }

    /**
     * Creates a new ConfiguredIngredient with the given item and default stack data (count 1).
     *
     * @param count the count of the item
     * @param item  the item to include in the ingredient
     */
    @SuppressWarnings("deprecation")
    public ConfiguredIngredient(int count, class_1792 item)
    {
        this(class_6885.method_40242(Arrays.stream(new class_1792[]{item}).map(class_1792::method_40131).toList()), StackDataPayload.create(count));
    }

    /**
     * Creates a new ConfiguredIngredient with the given item and default stack data (count 1).
     *
     * @param item the item to include in the ingredient
     */
    @SuppressWarnings("deprecation")
    public ConfiguredIngredient(class_1792 item)
    {
        this(class_6885.method_40242(Arrays.stream(new class_1792[]{item}).map(class_1792::method_40131).toList()), StackDataPayload.create(1));
    }

    /**
     * Creates a new ConfiguredIngredient with the given items and specified count and components.
     *
     * @param entries   the items to include in the ingredient
     * @param count     the count of each item
     * @param components the component changes for the stack data
     */
    public ConfiguredIngredient(class_6885<class_1792> entries, int count, class_9326 components)
    {
        this(entries, StackDataPayload.create(count, components));
    }

    /**
     * Retrieves a list of ItemStacks that match the configured ingredients.
     *
     * @return a list of matching ItemStacks
     */
    public List<class_1799> getMatchingStacks()
    {
        return this.entries.method_40239().map(item -> new class_1799(item, this.stackData.count(), this.stackData.components())).toList();
    }

    /**
     * Tests if the given stack can be used in a recipe, considering count and components.
     *
     * @param stack the stack to test
     * @return true if the stack matches the ingredient, false otherwise
     */
    public boolean testForRecipe(class_1799 stack)
    {
        return test(stack, MathHelper.countLessThanOrEquals(stack.method_7947()));
    }

    /**
     * Tests if the given stack can be used in a recipe, ignoring components.
     *
     * @param stack the stack to test
     * @return true if the stack matches the ingredient, false otherwise
     */
    public boolean testForRecipeIgnoreComponents(class_1799 stack)
    {
        return this.entries.method_40239().anyMatch(item ->
                stack.method_7909() == item.comp_349() &&
                this.stackData.count() >= stack.method_7947());
    }

    /**
     * Tests if the given stack can be used in a recipe, considering count and components.
     *
     * @param stack       the stack to test
     * @param matchCount  whether to match the count of the ingredient
     * @param matchComponents whether to match the component changes of the ingredient
     * @return true if the stack matches the ingredient, false otherwise
     */
    public boolean test(class_1799 stack, boolean matchCount, boolean matchComponents)
    {
        return this.entries.method_40239().anyMatch(item ->
                stack.method_7909() == item.comp_349() &&
                (!matchCount || stack.method_7947() == this.stackData.count()) &&
                (!matchComponents || this.stackData.components().equals(stack.method_57380())));
    }

    /**
     * Tests if the given stack can be used in a recipe, considering count and components.
     *
     * @param stack the stack to test
     * @return true if the stack matches the ingredient, false otherwise
     */
    public boolean test(class_1799 stack)
    {
        return test(stack, true, true);
    }

    /**
     * Tests if the given stack can be used in a recipe, considering count.
     *
     * @param stack       the stack to test
     * @param countPredicate a predicate for matching the count of the ingredient
     * @return true if the stack matches the ingredient, false otherwise
     */
    public boolean test(class_1799 stack, Predicate<Integer> countPredicate)
    {
        return this.entries.method_40239().anyMatch(item ->
                  stack.method_7909() == item.comp_349() &&
                  countPredicate.test(stackData.count()) &&
                  this.stackData.components().equals(stack.method_57380()));
    }

    /**
     * Creates a display for the configured ingredient.
     *
     * @return the SlotDisplay instance
     */
    public class_10302 toDisplay()
    {
        if(isEmpty())
            return class_10302.class_10305.field_54681;

        return new class_10302.class_10304(
                getMatchingStacks().stream()
                        .map(class_10302.class_10307::new)
                        .map(class_10302.class::cast)
                        .toList()
        );
    }

    /**
     * Checks if the configured ingredient is empty.
     *
     * @return true if the ingredient is empty, false otherwise
     */
    public boolean isEmpty()
    {
        return this == EMPTY;
    }
}