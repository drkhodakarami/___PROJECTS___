/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.records;

import com.mojang.serialization.MapCodec;
import com.mojang.serialization.codecs.RecordCodecBuilder;
import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.network.ExtraPacketCodecs;
import net.minecraft.class_10302;
import net.minecraft.class_1792;
import net.minecraft.class_1799;
import net.minecraft.class_2960;
import net.minecraft.class_5321;
import net.minecraft.class_5819;
import net.minecraft.class_5862;
import net.minecraft.class_5863;
import net.minecraft.class_5864;
import net.minecraft.class_6016;
import net.minecraft.class_6017;
import net.minecraft.class_6018;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8710;
import net.minecraft.class_9129;
import net.minecraft.class_9139;
import java.util.stream.IntStream;

/**
 * Represents a custom payload containing output information for an item stack, including the item, count provider, and chance.
 */
@SuppressWarnings("unused")
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")

public record OutputItemStackPayload(class_1792 output, class_6017 count, class_5863 chance) implements class_8710
{
    /**
     * The unique identifier for this custom payload.
     */
    public static final class_9154<BlockPosPayload> ID = new class_9154<>(class_2960.method_60655("jiralib", "output_item_stack_payload"));

    /**
     * The default chance value (1.0f).
     */
    public static final class_5862 DEFAULT_CHANCE = class_5862.method_33908(1.0f);

    /**
     * An empty instance of OutputItemStackPayload.
     */
    public static final OutputItemStackPayload EMPTY = new OutputItemStackPayload(class_1799.field_8037);

    /**
     * The codec used to serialize and deserialize the OutputItemStackPayload.
     */
    public static final MapCodec<OutputItemStackPayload> CODEC = RecordCodecBuilder.mapCodec(inst -> inst.group(
            class_7923.field_41178.method_39673().fieldOf("output").forGetter(OutputItemStackPayload::output),
            class_6017.field_29946.fieldOf("count").forGetter(OutputItemStackPayload::count),
            class_5863.field_29007.fieldOf("chance").forGetter(OutputItemStackPayload::chance)
    ).apply(inst, OutputItemStackPayload::new));

    /**
     * The packet codec used to send and receive the OutputItemStackPayload.
     */
    public static final class_9139<class_9129, OutputItemStackPayload> PACKET_CODEC =
            class_9139.method_56437(OutputItemStackPayload::encode, OutputItemStackPayload::decode);

    /**
     * Constructs a new {@link OutputItemStackPayload} and performs necessary validations.
     *
     * @throws IllegalArgumentException if any of the parameters are null
     */
    public OutputItemStackPayload
    {
        if(output == null)
            throw new IllegalArgumentException("Item can't be null");
        if(count == null)
            throw new IllegalArgumentException("Count can't be null");
        if(chance == null)
            throw new IllegalArgumentException("Chance can't be null");
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the specified item, count, and chance.
     *
     * @param output The item to be included in the payload.
     * @param count  The count of items.
     * @param chance The chance of the item being generated.
     */
    public OutputItemStackPayload(class_1792 output, int count, float chance)
    {
        this(output, class_6016.method_34998(count), class_5862.method_33908(chance));
    }

    /**
     * Constructs an {@link OutputItemStackPayload} from a given {@link class_1799}.
     *
     * @param stack The {@link class_1799} to be converted into the payload.
     * @throws IllegalArgumentException if the stack is null or its item is null
     */
    public OutputItemStackPayload(class_1799 stack)
    {
        this(stack.method_7909(), class_6016.method_34998(stack.method_7947()), DEFAULT_CHANCE);
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the given item and count.
     *
     * @param output The item to be included in the payload, cannot be null.
     * @param count  The count provider for the items, cannot be null or provide zero or negative values.
     * @param chance The chance of the item appearing, cannot be null or less than 0.
     */
    public OutputItemStackPayload(class_1792 output, class_6017 count, float chance)
    {
        this(output, count, class_5862.method_33908(chance));
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the given item and count.
     *
     * @param output The item to be included in the payload, cannot be null.
     * @param count  The count of items, cannot be zero or negative.
     * @param chance The chance provider for the item appearing, cannot be null.
     */
    public OutputItemStackPayload(class_1792 output, int count, class_5863 chance)
    {
        this(output, class_6016.method_34998(count), chance);
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the given item and count.
     *
     * @param output The item to be included in the payload, cannot be null.
     * @param count  The count of items, cannot be zero or negative.
     */
    public OutputItemStackPayload(class_1792 output, int count)
    {
        this(output, class_6016.method_34998(count), DEFAULT_CHANCE);
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the given item and count provider.
     *
     * @param output The item to be included in the payload, cannot be null.
     * @param count  The count provider for the items, cannot be null or provide zero or negative values.
     */
    public OutputItemStackPayload(class_1792 output, class_6017 count)
    {
        this(output, count, DEFAULT_CHANCE);
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the given item and chance.
     *
     * @param output The item to be included in the payload, cannot be null.
     * @param chance The chance of the item appearing, cannot be null or less than 0.
     */
    public OutputItemStackPayload(class_1792 output, float chance)
    {
        this(output, class_6016.method_34998(1), class_5862.method_33908(chance));
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the given item and chance provider.
     *
     * @param output The item to be included in the payload, cannot be null.
     * @param chance The chance provider for the item appearing, cannot be null.
     */
    public OutputItemStackPayload(class_1792 output, class_5863 chance)
    {
        this(output, class_6016.method_34998(1), chance);
    }

    /**
     * Constructs an {@link OutputItemStackPayload} with the given item.
     *
     * @param output The item to be included in the payload, cannot be null.
     */
    public OutputItemStackPayload(class_1792 output)
    {
        this(output, class_6016.method_34998(1), DEFAULT_CHANCE);
    }

    /**
     * Constructs an {@link OutputItemStackPayload} from a given {@link class_1799} and chance.
     *
     * @param stack  The {@link class_1799} to be converted into the payload, cannot be null or empty.
     * @param chance The chance of the item appearing, cannot be null or less than 0.
     */
    public OutputItemStackPayload(class_1799 stack, float chance)
    {
        this(stack.method_7909(), class_6016.method_34998(stack.method_7947()), class_5862.method_33908(chance));
    }

    /**
     * Constructs an {@link OutputItemStackPayload} from a given {@link class_1799} and chance provider.
     *
     * @param stack  The {@link class_1799} to be converted into the payload, cannot be null or empty.
     * @param chance The chance provider for the item appearing, cannot be null.
     */
    public OutputItemStackPayload(class_1799 stack, class_5863 chance)
    {
        this(stack.method_7909(), class_6016.method_34998(stack.method_7947()), chance);
    }

    /**
     * Represents a payload for an output item stack with configurable properties.
     */
    public class_1799 createStack(class_5819 random)
    {
        return this.chance.method_33920(random) < random.method_43057()
               ? class_1799.field_8037
               : new class_1799(this.output, this.count.method_35008(random));
    }

    /**
     * Converts this payload to a display representation of multiple item stacks.
     *
     * @return A {@link class_10302} containing multiple item stacks.
     */
    public class_10302 toDisplay()
    {
        return new class_10302.class_10304(
                IntStream.range(this.count.method_35009(), this.count.method_35011() + 1)
                        .mapToObj(c -> new class_1799(this.output, c))
                        .map(class_10302.class_10307::new)
                        .map(class_10302.class::cast)
                        .toList()
        );
    }

    /**
     * Encodes the {@link OutputItemStackPayload} into a byte buffer.
     *
     * @param buf The registry byte buffer to encode the payload into.
     * @param stackPayload The payload to encode.
     */
    private static void encode(class_9129 buf, OutputItemStackPayload stackPayload)
    {
        buf.method_44116(class_7923.field_41178.method_29113(stackPayload.output()).orElseThrow());

        class_7923.field_41140.method_29113(stackPayload.count().method_35012()).ifPresent(buf::method_44116);
        ExtraPacketCodecs.encode(buf, stackPayload.count());

        class_7923.field_41139.method_29113(stackPayload.chance().method_33923()).ifPresent(buf::method_44116);
        ExtraPacketCodecs.encode(buf, stackPayload.chance());
    }

    /**
     * Decodes a {@link OutputItemStackPayload} from a byte buffer.
     *
     * @param buf The registry byte buffer to decode the payload from.
     * @return The decoded {@link OutputItemStackPayload}.
     */
    private static OutputItemStackPayload decode(class_9129 buf)
    {
        class_1792 item = class_7923.field_41178.method_29107(buf.method_44112(class_7924.field_41197));

        class_5321<class_6018<?>> countType = buf.method_44112(class_7924.field_41196);
        class_6018<?> countTypeInstance = class_7923.field_41140.method_29107(countType);
        class_6017 count = ExtraPacketCodecs.decode(buf, countTypeInstance);

        class_5321<class_5864<?>> chanceType = buf.method_44112(class_7924.field_41269);
        class_5864<?> chanceTypeInstance = class_7923.field_41139.method_29107(chanceType);
        class_5863 chance = ExtraPacketCodecs.decode(buf, chanceTypeInstance);

        return new OutputItemStackPayload(item, count, chance);
    }

    /**
     * Retrieves the unique identifier for this custom payload.
     *
     * @return the unique identifier
     */
    @Override
    public class_9154<? extends class_8710> method_56479()
    {
        return ID;
    }
}