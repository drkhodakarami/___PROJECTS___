/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jibase.client.utils;

import jiraiyah.jibase.annotations.*;
import net.minecraft.class_11246;
import net.minecraft.class_310;
import net.minecraft.class_332;
import net.minecraft.class_768;

/**
 * Class representing an information area in the Minecraft client GUI.
 *
 * @author Jiraiyah
 * @since 2025-04-18
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class InfoArea extends class_332
{
    /**
     * The area of the information region.
     */
    protected final class_768 area;

    /**
     * Constructs an InfoArea with default coordinates (0, 0, 0, 0).
     *
     * @param client The MinecraftClient instance.
     * @param state  The GuiRenderState for rendering.
     */
    public InfoArea(class_310 client, class_11246 state)
    {
        super(client, state);
        this.area = new class_768(0, 0, 0, 0);
    }

    /**
     * Constructs an InfoArea with the specified coordinates.
     *
     * @param client The MinecraftClient instance.
     * @param state  The GuiRenderState for rendering.
     * @param area   The rectangle representing the area of the information region.
     */
    public InfoArea(class_310 client, class_11246 state, class_768 area)
    {
        super(client, state);
        this.area = area;
    }

    /**
     * Draws the content of the information area.
     *
     * @param context The DrawContext for drawing operations.
     */
    public void draw(class_332 context)
    {}

    /**
     * Checks if the mouse is over the specified area.
     *
     * @param mouseX The x-coordinate of the mouse.
     * @param mouseY The y-coordinate of the mouse.
     * @return true if the mouse is within the bounds of the area; false otherwise.
     */
    public boolean isMouseOver(double mouseX, double mouseY)
    {
        return MouseHelper.isMouseOver(mouseX, mouseY, this.area);
    }
}