/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jigui.widgets;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.client.utils.MouseHelper;
import jiraiyah.jibase.utils.StringHelper;
import jiraiyah.jigui.constants.FluidContainerTextures;
import jiraiyah.jigui.records.TextureData;
import jiraiyah.jigui.utils.ScreenHelper;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandler;
import net.fabricmc.fabric.api.client.render.fluid.v1.FluidRenderHandlerRegistry;
import net.fabricmc.fabric.api.transfer.v1.fluid.FluidConstants;
import net.fabricmc.fabric.api.transfer.v1.fluid.base.SingleFluidStorage;
import net.minecraft.class_1058;
import net.minecraft.class_10799;
import net.minecraft.class_1937;
import net.minecraft.class_2338;
import net.minecraft.class_2561;
import net.minecraft.class_2960;
import net.minecraft.class_310;
import net.minecraft.class_327;
import net.minecraft.class_332;
import net.minecraft.class_339;
import net.minecraft.class_3610;
import net.minecraft.class_3611;
import net.minecraft.class_4068;
import net.minecraft.class_8021;
import net.minecraft.class_9848;
import java.util.List;
import java.util.function.Consumer;
import java.util.function.Supplier;

@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class FluidWidget implements class_4068, class_8021
{
    private final SingleFluidStorage fluidStorage;

    private final int backgroundX, backgroundY, backgroundWidth, backgroundHeight;
    private final int markerX, markerY, markerWidth, markerHeight;

    private final int backgroundU, backgroundV, markerU, markerV;

    private final int fluidX, fluidY, fluidWidth, fluidHeight;

    private int x, y;

    private final int backgroundSizeWidth, backgroundSizeHeight;
    private final int markerSizeWidth, markerSizeHeight;

    private final Supplier<class_2338> posSupplier;

    private final class_2960 backgroundTexture, markerTexture;

    public FluidWidget(SingleFluidStorage fluidStorage,
                       int x, int y, boolean drawBackground,
                       int backgroundX, int backgroundY, int backgroundWidth, int backgroundHeight,
                       int markerX, int markerY, int markerWidth, int markerHeight,
                       int fluidX, int fluidY, int fluidWidth, int fluidHeight,
                       int backgroundU, int backgroundV, int markerU, int markerV,
                       int backgroundSizeWidth, int backgroundSizeHeight,
                       int markerSizeWidth, int markerSizeHeight,
                       class_2960 backgroundTexture, class_2960 markerTexture,
                       Supplier<class_2338> posSupplier)
    {
        this.fluidStorage = fluidStorage;
        this.backgroundX = backgroundX;
        this.backgroundY = backgroundY;
        this.backgroundWidth = backgroundWidth;
        this.backgroundHeight = backgroundHeight;
        this.markerX = markerX;
        this.markerY = markerY;
        this.markerWidth = markerWidth;
        this.markerHeight = markerHeight;
        this.posSupplier = posSupplier;
        this.backgroundTexture = backgroundTexture;
        this.markerTexture = markerTexture;
        this.backgroundU = backgroundU;
        this.backgroundV = backgroundV;
        this.markerU = markerU;
        this.markerV = markerV;
        this.fluidX = fluidX;
        this.fluidY = fluidY;
        this.fluidWidth = fluidWidth;
        this.fluidHeight = fluidHeight;
        this.backgroundSizeWidth = backgroundSizeWidth;
        this.backgroundSizeHeight = backgroundSizeHeight;
        this.markerSizeWidth = markerSizeWidth;
        this.markerSizeHeight = markerSizeHeight;
        this.x = x;
        this.y = y;
    }


    @ThanksTo(youtubeUsers = "TurtyWurty", discordUsers = "TurtyWurty")
    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float deltaTicks)
    {
        if(fluidStorage == null || fluidStorage.variant == null)
            return;

        // Render the fluid widget background
        ScreenHelper.drawTexture(context, backgroundTexture,
                                x + backgroundX, y + backgroundY,
                                 backgroundU, backgroundV,
                                 backgroundWidth, backgroundHeight,
                                 backgroundSizeWidth, backgroundSizeHeight);

        class_3611 fluid = fluidStorage.variant.getFluid();
        long amount = fluidStorage.getAmount();
        long capacity = fluidStorage.getCapacity();
        int barHeight = Math.round((float) amount / capacity * fluidHeight);

        //region Fluid Render Handler Params
        FluidRenderHandler fluidRenderHandler = FluidRenderHandlerRegistry.INSTANCE.get(fluid);
        if(fluidRenderHandler == null || amount <= 0)
        {
            ScreenHelper.drawTexture(context, markerTexture,
                                     markerX, markerY,
                                     markerU, markerV,
                                     markerWidth, markerHeight,
                                     markerSizeWidth, markerSizeHeight);
            return;
        }

        class_2338 pos = posSupplier.get();
        class_3610 fluidState = fluid.method_15785();
        class_1937 world = class_310.method_1551().field_1687;

        class_1058 stillTexture = fluidRenderHandler.getFluidSprites(world, pos, fluidState)[0];

        int tintColor = fluidRenderHandler.getFluidColor(world, pos, fluidState);

        float red = (tintColor >> 16 & 0xFF) / 255.0F;
        float green = (tintColor >> 8 & 0xFF) / 255.0F;
        float blue = (tintColor & 0xFF) / 255.0F;
        //endregion

        // Render the fluid widget fluid
        ScreenHelper.renderTiledSprite(context, class_10799.field_56883, stillTexture,
                                      x + fluidX, y + fluidY + fluidHeight - barHeight, fluidWidth, barHeight,
                                       class_9848.method_61318(1.0F, red, green, blue));
        // Render the fluid widget marker
        ScreenHelper.drawTexture(context, markerTexture,
                                x + markerX, y + markerY,
                                 markerU, markerV,
                                 markerWidth, markerHeight,
                                 markerSizeWidth, markerSizeHeight);

        if(MouseHelper.isMouseOver(mouseX, mouseY, x + fluidX, y + fluidY, fluidWidth, fluidHeight))
            drawTooltip(context, mouseX, mouseY);
    }

    @Override
    public void method_46421(int x)
    {
        this.x = x;
    }

    @Override
    public void method_46419(int y)
    {
        this.y = y;
    }

    @Override
    public int method_46426()
    {
        return x;
    }

    @Override
    public int method_46427()
    {
        return y;
    }

    @Override
    public int method_25368()
    {
        return backgroundWidth;
    }

    @Override
    public int method_25364()
    {
        return backgroundHeight;
    }

    @Override
    public void method_48206(Consumer<class_339> consumer) {}

    public SingleFluidStorage getFluidStorage()
    {
        return fluidStorage;
    }

    protected  void drawTooltip(class_332 context, int mouseX, int mouseY)
    {
        class_3611 fluid = fluidStorage.variant.getFluid();

        long amount = fluidStorage.getAmount();
        long capacity = fluidStorage.getCapacity();

        if(fluid == null || amount <= 0)
            return;

        class_327 textRenderer = class_310.method_1551().field_1772;

        int amountInMillibuckets = (int) (((float) amount / FluidConstants.BUCKET) * 1000);
        int capacityInMillibuckets = (int) (((float) capacity / FluidConstants.BUCKET) * 1000);

        String amountText = StringHelper.formatted(amountInMillibuckets);
        String capacityText = StringHelper.formatted(capacityInMillibuckets);

        List<class_2561> texts = List.of(
                class_2561.method_43471(fluid.method_15785().method_15759().method_26204().method_63499()),
                class_2561.method_43470((amountText + " / " + capacityText + " mB")));

        context.method_51434(textRenderer, texts, mouseX, mouseY);
    }

    public static class Builder
    {
        private SingleFluidStorage fluidStorage;

        private int backgroundX, backgroundY, backgroundWidth, backgroundHeight;
        private int markerX, markerY, markerWidth, markerHeight;

        private int backgroundU, backgroundV, markerU, markerV;

        private int fluidX, fluidY, fluidWidth, fluidHeight;

        private final int x, y;

        private int backgroundSizeWidth, backgroundSizeHeight;
        private int markerSizeWidth, markerSizeHeight;

        private Supplier<class_2338> posSupplier = () -> null;

        private class_2960 backgroundTexture, markerTexture;

        private final boolean drawBackground;

        public Builder(int x, int y)
        {
            this(x, y, true);
        }

        public Builder(int x, int y, boolean drawBackground)
        {
            this.x = x;
            this.y = y;
            this.drawBackground = drawBackground;
        }

        public Builder fluidStorage(SingleFluidStorage fluidStorage)
        {
            this.fluidStorage = fluidStorage;
            return this;
        }

        public Builder backgroundTexture(TextureData data)
        {
            this.backgroundX = data.x();
            this.backgroundY = data.y();
            this.backgroundWidth = data.width();
            this.backgroundHeight = data.height();
            this.backgroundTexture = data.id();
            this.backgroundU = data.u();
            this.backgroundV = data.v();
            this.backgroundSizeWidth = data.textureWidth();
            this.backgroundSizeHeight = data.textureHeight();
            return this;
        }

        public Builder markerTexture(TextureData data)
        {
            this.markerX = data.x();
            this.markerY = data.y();
            this.markerWidth = data.width();
            this.markerHeight = data.height();
            this.markerTexture = data.id();
            this.markerU = data.u();
            this.markerV = data.v();
            this.markerSizeWidth = data.textureWidth();
            this.markerSizeHeight = data.textureHeight();
            return this;
        }

        public Builder textures(TextureData backgroundData, TextureData markerData)
        {
            return this.backgroundTexture(backgroundData).markerTexture(markerData);
        }

        public Builder backgroundRect(int x, int y, int width, int height)
        {
            this.backgroundX = x;
            this.backgroundY = y;
            this.backgroundWidth = width;
            this.backgroundHeight = height;
            return this;
        }

        public Builder markerRect(int x, int y, int width, int height)
        {
            this.markerX = x;
            this.markerY = y;
            this.markerWidth = width;
            this.markerHeight = height;
            return this;
        }

        public Builder fluidRect(int x, int y, int width, int height)
        {
            this.fluidX = x;
            this.fluidY = y;
            this.fluidWidth = width;
            this.fluidHeight = height;
            return this;
        }

        public Builder backgroundTexture(class_2960 texture, int u, int v, int width, int height)
        {
            this.backgroundTexture = texture;
            this.backgroundU = u;
            this.backgroundV = v;
            this.backgroundSizeWidth = width;
            this.backgroundSizeHeight = height;
            return this;
        }

        public Builder markerTexture(class_2960 texture, int u, int v, int width, int height)
        {
            this.markerTexture = texture;
            this.markerU = u;
            this.markerV = v;
            this.markerSizeWidth = width;
            this.markerSizeHeight = height;
            return this;
        }

        public Builder posSupplier(Supplier<class_2338> posSupplier)
        {
            this.posSupplier = posSupplier;
            return this;
        }

        public Builder useDefaultValues(SingleFluidStorage fluidStorage, Supplier<class_2338> posSupplier)
        {
            return this.fluidStorage(fluidStorage)
                    .posSupplier(posSupplier)
                    .textures(FluidContainerTextures.Normal.BACKGROUND, FluidContainerTextures.Normal.MARKER_SMALL)
                    .fluidRect(FluidContainerTextures.Normal.FLUID_RECT.method_3321(),
                               FluidContainerTextures.Normal.FLUID_RECT.method_3322(),
                               FluidContainerTextures.Normal.FLUID_RECT.method_3319(),
                               FluidContainerTextures.Normal.FLUID_RECT.method_3320());
        }

        public FluidWidget build()
        {
            return new FluidWidget(fluidStorage,
                                   x, y, drawBackground,
                                   backgroundX, backgroundY, backgroundWidth, backgroundHeight,
                                   markerX, markerY, markerWidth, markerHeight,
                                   fluidX, fluidY, fluidWidth, fluidHeight,
                                   backgroundU, backgroundV, markerU, markerV,
                                   backgroundSizeWidth, backgroundSizeHeight,
                                   markerSizeWidth, markerSizeHeight,
                                   backgroundTexture, markerTexture, posSupplier);
        }
    }
}