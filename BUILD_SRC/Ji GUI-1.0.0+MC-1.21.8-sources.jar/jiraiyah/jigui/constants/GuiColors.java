/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jigui.constants;

import net.minecraft.class_9848;

@SuppressWarnings("unused")
public class GuiColors
{
    public static class Indicator
    {
        public static final int DARK_RED = class_9848.method_61323(110, 11, 11);
        public static final int LIME = class_9848.method_61323(0, 255, 42);
        public static final int RED = class_9848.method_61323(255, 0, 42);
        public static final int DARK_BLUE = class_9848.method_61323(11, 18, 110);
        public static final int DARKEST_BLUE = class_9848.method_61323(7, 7, 67);
        public static final int DARK_GREEN = class_9848.method_61323(7, 73, 12);
        public static final int GREEN = class_9848.method_61323(42, 146, 37);
        public static final int DARKEST_GREEN = class_9848.method_61323(5, 49, 3);
        public static final int YELLOW = class_9848.method_61323(252, 255, 0);
        public static final int GOLD = class_9848.method_61323(129, 130, 39);
        public static final int OLIVE = class_9848.method_61323(89, 119, 36);
        public static final int NEAR_BLACK = class_9848.method_61323(21, 21, 21);
        public static final int NEAR_WHITE = class_9848.method_61323(236, 236, 220);
        public static final int CYAN = class_9848.method_61323(23, 231, 219);
        public static final int BROWN = class_9848.method_61323(68, 31, 6);
        public static final int ORANGE = class_9848.method_61323(247, 157, 16);
        public static final int PINK = class_9848.method_61323(249, 12, 241);
        public static final int DARKEST_PINK = class_9848.method_61323(49, 3, 47);
        public static final int DARK_PINK = class_9848.method_61323(133, 7, 129);
        public static final int MAGENTA = class_9848.method_61323(179, 4, 119);
        public static final int DARKEST_PURPLE = class_9848.method_61323(36, 6, 57);
        public static final int DARK_PURPLE = class_9848.method_61323(72, 17, 110);
        public static final int PURPLE = class_9848.method_61323(149, 13, 243);
    }

    public static class Background
    {
        public static final int PANEL = class_9848.method_61323(198, 198, 198);
        public static final int BORDER_HIGHLIGHT = class_9848.method_61323(255, 255, 255);
        public static final int BORDER_SHADOW = class_9848.method_61323(85, 85, 85);
    }
}