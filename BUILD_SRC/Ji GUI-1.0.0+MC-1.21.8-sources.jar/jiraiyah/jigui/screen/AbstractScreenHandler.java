/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jigui.screen;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.data.CachedBlockEntity;
import jiraiyah.jibase.records.BlockPosPayload;
import net.minecraft.class_1657;
import net.minecraft.class_1661;
import net.minecraft.class_1703;
import net.minecraft.class_1735;
import net.minecraft.class_1799;
import net.minecraft.class_1937;
import net.minecraft.class_2248;
import net.minecraft.class_2586;
import net.minecraft.class_3914;
import net.minecraft.class_3917;
import java.util.List;

@SuppressWarnings("unused")
@Developer("TurtyWurty")
@ModifiedBy("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/DaRealTurtyWurty/Industria")
@Discord("https://discord.turtywurty.dev/")
@Youtube("https://www.youtube.com/@TurtyWurty")

public abstract class AbstractScreenHandler <T extends class_2586> extends class_1703
{
    protected final T blockEntity;
    protected final class_3914 context;
    protected final class_1937 world;
    protected final class_2248 block;
    protected final class_1661 playerInventory;
    protected final class_1657 player;

    public AbstractScreenHandler(class_3917<?> type, int syncID, class_1661 playerInventory, BlockPosPayload payload, Class<T> blockEntityClass)
    {
        this(type, syncID, playerInventory, payload, new CachedBlockEntity<>(blockEntityClass));
    }

    public AbstractScreenHandler(class_3917<?> type, int syncID, class_1661 playerInventory, BlockPosPayload payload, CachedBlockEntity<T> cachedBE)
    {
        this(type, syncID, playerInventory, cachedBE.apply(playerInventory, payload.pos()));
    }

    public AbstractScreenHandler(class_3917<?> type, int syncId, class_1661 playerInventory, BlockPosPayload payload)
    {
        //noinspection unchecked
        this(type, syncId, playerInventory, (T) playerInventory.field_7546.method_37908().method_8321(payload.pos()));
    }

    public AbstractScreenHandler(class_3917<?> type, int syncId, class_1661 playerInventory, T blockEntity)
    {
        super(type, syncId);
        this.world = playerInventory.field_7546.method_37908();
        this.blockEntity = blockEntity;
        this.context = class_3914.method_17392(this.world, this.blockEntity.method_11016());
        this.playerInventory = playerInventory;
        this.player = playerInventory.field_7546;
        this.block = this.world.method_8320(this.blockEntity.method_11016()).method_26204();

        if (addPlayerInventory())
            method_61624(playerInventory, getPlayerInventoryX(), getPlayerInventoryY());
    }

    @Override
    public class_1799 method_7601(class_1657 player, int slotIndex)
    {
        class_1799 newStack = class_1799.field_8037;
        class_1735 slot = this.field_7761.get(slotIndex);
        if (!slot.method_7681())
            return newStack;

        class_1799 stackInSlot = slot.method_7677();
        newStack = stackInSlot.method_7972();
        if(slotIndex < getInventorySize())
        {
            if(!method_7616(stackInSlot, this.field_7761.size() - 9, this.field_7761.size(), true))
                if(!method_7616(stackInSlot, this.field_7761.size() - 36, this.field_7761.size() - 9, false))
                    return class_1799.field_8037;
        }
        else
        {
            if(!method_7616(stackInSlot, 0, getInventorySize(), false))
                return class_1799.field_8037;
        }

        if(stackInSlot.method_7960())
            slot.method_53512(class_1799.field_8037);
        else
            slot.method_7668();

        return newStack;
    }

    @Override
    public boolean method_7597(class_1657 player)
    {
        boolean validBlock = false;
        for (class_2248 block : getValidBlocks())
        {
            if(method_17695(this.context, player, block))
            {
                validBlock = true;
                break;
            }
        }
        return validBlock;
    }

    public T getBlockEntity()
    {
        return this.blockEntity;
    }

    public class_1657 getPlayer()
    {
        return this.player;
    }


    protected abstract List<class_2248> getValidBlocks();
    protected abstract boolean addPlayerInventory();

    public abstract int getInventorySize();
    public abstract int getPlayerInventoryY();

    public int getPlayerInventoryX()
    {
        return 8;
    }
}