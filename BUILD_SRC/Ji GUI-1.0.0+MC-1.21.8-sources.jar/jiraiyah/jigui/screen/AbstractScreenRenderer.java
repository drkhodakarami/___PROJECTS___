/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jigui.screen;

import jiraiyah.jigui.constants.ContainerBaseTextures;
import jiraiyah.jigui.utils.ScreenHelper;
import net.minecraft.class_1661;
import net.minecraft.class_2561;
import net.minecraft.class_2586;
import net.minecraft.class_332;
import net.minecraft.class_465;

public abstract class AbstractScreenRenderer<B extends class_2586, T extends AbstractScreenHandler<B>> extends class_465<T>
{
    public AbstractScreenRenderer(T handler, class_1661 inventory, class_2561 title)
    {
        super(handler, inventory, title);
    }

    @Override
    protected void method_25426()
    {
        if(shouldDrawContainerName())
        {
            if(shouldContainNameCentered())
                this.field_25267 = (this.field_2792 - this.field_22793.method_27525(field_22785)) / 2;
            else
                this.field_25267 = 8;
        }
        else
            this.field_25267 = 100_000;

        if(shouldDrawInventoryName())
        {
            if(shouldInventoryNameCentered())
                this.field_25269 = (this.field_2792 - this.field_22793.method_27525(field_29347)) / 2;
            else
                this.field_25269 = 8;

            this.field_25270 = this.field_2779 - 94;
        }
        else
            this.field_25269 = 100_000;

        this.field_2792 = getBackgroundWidth();
        this.field_2779 = getBackgroundHeight();

        super.method_25426();
    }

    @Override
    protected void method_2389(class_332 context, float deltaTicks, int mouseX, int mouseY)
    {
        ScreenHelper.drawBackground(context, this.field_2776, this.field_2800, this.getBackgroundWidth(), this.getBackgroundHeight());

        if(field_2797.addPlayerInventory())
            ScreenHelper.drawTexture(context, ContainerBaseTextures.PLAYER_INVENTORY.id(),
                                     this.field_2776 + field_2797.getPlayerInventoryX() - 1 + ContainerBaseTextures.PLAYER_INVENTORY.x(),
                                     this.field_2800 + field_2797.getPlayerInventoryY() - 1 + ContainerBaseTextures.PLAYER_INVENTORY.y(),
                                     ContainerBaseTextures.PLAYER_INVENTORY.u(),
                                     ContainerBaseTextures.PLAYER_INVENTORY.v(),
                                     ContainerBaseTextures.PLAYER_INVENTORY.width(),
                                     ContainerBaseTextures.PLAYER_INVENTORY.height(),
                                     ContainerBaseTextures.PLAYER_INVENTORY.textureWidth(),
                                     ContainerBaseTextures.PLAYER_INVENTORY.textureHeight());
    }

    protected boolean shouldInventoryNameCentered()
    {
        return false;
    }

    protected boolean shouldDrawInventoryName()
    {
        return false;
    }

    protected boolean shouldContainNameCentered()
    {
        return true;
    }

    protected boolean shouldDrawContainerName()
    {
        return true;
    }

    protected abstract int getBackgroundHeight();
    protected abstract int getBackgroundWidth();
}