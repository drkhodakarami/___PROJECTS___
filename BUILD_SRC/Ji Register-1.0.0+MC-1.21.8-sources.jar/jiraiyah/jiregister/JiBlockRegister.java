/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiregister;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.utils.BaseHelper;
import net.minecraft.block.*;
import net.minecraft.class_2248;
import net.minecraft.class_2269;
import net.minecraft.class_2323;
import net.minecraft.class_2349;
import net.minecraft.class_2354;
import net.minecraft.class_2378;
import net.minecraft.class_2440;
import net.minecraft.class_2482;
import net.minecraft.class_2510;
import net.minecraft.class_2533;
import net.minecraft.class_2544;
import net.minecraft.class_4719;
import net.minecraft.class_4970;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8177;
import java.util.function.Function;

/**
 * Provides utility methods for registering blocks in Minecraft.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class JiBlockRegister
{
    /**
     * The unique identifier for the mod.
     */
    private final String modId;

    /**
     * Constructs a new JiBlockRegister with the specified mod ID.
     *
     * @param modId The unique identifier for the mod.
     */
    public JiBlockRegister(String modId)
    {
        this.modId = modId;
    }

    /**
     * Registers a block with default settings and uses the provided copy block as a template.
     *
     * @param name The name of the block to register.
     * @return The registered block.
     */
    public class_2248 register(String name)
    {
        return register(name, class_2248::new);
    }

    /**
     * Registers a block with default settings and copies properties from another block.
     *
     * @param name The name of the block to register.
     * @param copyBlock The block whose properties to copy.
     * @return The registered block.
     */
    public class_2248 register(String name, class_2248 copyBlock)
    {
        return register(name, copyBlock, class_2248::new);
    }

    /**
     * Registers a block with custom settings and uses the provided copy block as a template.
     *
     * @param name The name of the block to register.
     * @param settings Custom settings for the block.
     * @return The registered block.
     */
    public class_2248 register(String name, class_4970.class_2251 settings)
    {
        return register(name, settings, class_2248::new);
    }

    /**
     * Registers a block using the provided factory function.
     *
     * @param name The name of the block to register.
     * @param block The block instance to register.
     * @return The registered block.
     */
    public <R extends class_2248> R registerBlock(String name, R block)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return class_2378.method_39197(class_7923.field_41175, key, block);
    }

    /**
     * Registers a block with default settings and copies properties from another block using the provided factory function.
     *
     * @param name The name of the block to register.
     * @param copyBlock The block whose properties to copy.
     * @param factory The factory function to create the block instance.
     * @return The registered block.
     */
    public <R extends class_2248> R register(String name, class_2248 copyBlock, Function<class_4970.class_2251, R> factory)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        R block = factory.apply(class_4970.class_2251.method_9630(copyBlock).method_63500(key));
        return class_2378.method_39197(class_7923.field_41175, key, block);
    }

    /**
     * Registers a block with custom settings and creates the block instance using the provided factory function.
     *
     * @param name The name of the block to register.
     * @param settings Custom settings for the block.
     * @param factory The factory function to create the block instance.
     * @return The registered block.
     */
    public <R extends class_2248> R register(String name, class_4970.class_2251 settings, Function<class_4970.class_2251, R> factory)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        R block = factory.apply(settings.method_63500(key));
        return class_2378.method_39197(class_7923.field_41175, key, block);
    }

    /**
     * Registers a block with default settings using the provided factory function.
     *
     * @param name The name of the block to register.
     * @param factory The factory function to create the block instance.
     * @return The registered block.
     */
    public <R extends class_2248> R register(String name, Function<class_4970.class_2251, R> factory)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        R block = factory.apply(class_4970.class_2251.method_9637().method_63500(key));
        return class_2378.method_39197(class_7923.field_41175, key, block);
    }

    /**
     * Registers a stairs block using the provided copy block.
     *
     * @param name The name of the stairs block to register.
     * @param stateBlock The state block for the stairs.
     * @param copyBlock The block whose properties to copy.
     * @return The registered stairs block.
     */
    public class_2510 registerStair(String name, class_2248 stateBlock, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2510(stateBlock.method_9564(),
                                                   class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a slab block using the provided copy block.
     *
     * @param name The name of the slab block to register.
     * @param copyBlock The block whose properties to copy.
     * @return The registered slab block.
     */
    public class_2482 registerSlab(String name, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2482(class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a button block using the provided settings and copy block.
     *
     * @param name The name of the button block to register.
     * @param blockType The type of block set for the button.
     * @param pressureTicks The number of ticks before the button activates.
     * @param copyBlock The block whose properties to copy.
     * @return The registered button block.
     */
    public class_2269 registerButton(String name, class_8177 blockType, int pressureTicks, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2269(blockType, pressureTicks,
                                                   class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a pressure plate block using the provided settings and copy block.
     *
     * @param name The name of the pressure plate block to register.
     * @param blockType The type of block set for the pressure plate.
     * @param copyBlock The block whose properties to copy.
     * @return The registered pressure plate block.
     */
    public class_2440 registerPressurePlate(String name, class_8177 blockType, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2440(blockType,
                                                   class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a fence block using the provided settings and copy block.
     *
     * @param name The name of the fence block to register.
     * @param copyBlock The block whose properties to copy.
     * @return The registered fence block.
     */
    public class_2354 registerFence(String name, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2354(class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a fence gate block using the provided settings and copy block.
     *
     * @param name The name of the fence gate block to register.
     * @param woodType The type of wood for the fence gate.
     * @param copyBlock The block whose properties to copy.
     * @return The registered fence gate block.
     */
    public class_2349 registerFenceGate(String name, class_4719 woodType, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2349(woodType, class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a wall block using the provided settings and copy block.
     *
     * @param name The name of the wall block to register.
     * @param copyBlock The block whose properties to copy.
     * @return The registered wall block.
     */
    public class_2544 registerWall(String name, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2544(class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a door block using the provided settings and copy block.
     *
     * @param name The name of the door block to register.
     * @param blockType The type of block set for the door.
     * @param copyBlock The block whose properties to copy.
     * @return The registered door block.
     */
    public class_2323 registerDoor(String name, class_8177 blockType, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2323(blockType,
                                              class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }

    /**
     * Registers a trapdoor block using the provided settings and copy block.
     *
     * @param name The name of the trapdoor block to register.
     * @param blockType The type of block set for the trapdoor.
     * @param copyBlock The block whose properties to copy.
     * @return The registered trapdoor block.
     */
    public class_2533 registerTrapdoor(String name, class_8177 blockType, class_2248 copyBlock)
    {
        class_5321<class_2248> key = BaseHelper.getKey(this.modId, name, class_7924.field_41254);
        return registerBlock(name, new class_2533(blockType,
                                                 class_4970.class_2251.method_9630(copyBlock).method_63500(key)));
    }
}