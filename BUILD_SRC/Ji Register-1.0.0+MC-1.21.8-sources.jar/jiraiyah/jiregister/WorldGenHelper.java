/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiregister;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.exceptions.Exceptions;
import net.minecraft.class_2975;
import net.minecraft.class_3031;
import net.minecraft.class_3037;
import net.minecraft.class_5321;
import net.minecraft.class_5450;
import net.minecraft.class_6792;
import net.minecraft.class_6793;
import net.minecraft.class_6796;
import net.minecraft.class_6797;
import net.minecraft.class_6799;
import net.minecraft.class_6880;
import net.minecraft.class_7891;
import net.minecraft.world.gen.placementmodifier.*;

import java.util.List;

/**
 * Provides utility methods for registering world generation features and placed features.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class WorldGenHelper
{
    /**
     * Private constructor to prevent instantiation.
     */
    public WorldGenHelper()
    {
        Exceptions.throwCtorAssertion();
    }

    /**
     * Registers a placed feature with the given configuration and modifiers.
     *
     * @param context       the registerable context for placing features
     * @param key           the registry key for the placed feature
     * @param configuration the configured feature to place
     * @param modifiers     the placement modifiers to apply
     */
    public static void registerPlacedFeature(class_7891<class_6796> context,
                                             class_5321<class_6796> key,
                                             class_6880<class_2975<?, ?>> configuration,
                                             List<class_6797> modifiers)
    {
        context.method_46838(key, new class_6796(configuration, List.copyOf(modifiers)));
    }

    /**
     * Registers a placed feature with the given configuration and modifiers.
     *
     * @param context       the registerable context for placing features
     * @param key           the registry key for the placed feature
     * @param configuration the configured feature to place
     * @param modifiers     the placement modifiers to apply
     */
    public static void registerPlacedFeature(class_7891<class_6796> context,
                                             class_5321<class_6796> key,
                                             class_6880<class_2975<?, ?>> configuration,
                                             class_6797... modifiers)
    {
        registerPlacedFeature(context, key, configuration, List.of(modifiers));
    }

    /**
     * Registers a configured feature with the given feature and configuration.
     *
     * @param context       the registerable context for placing features
     * @param key           the registry key for the configured feature
     * @param feature       the feature to configure
     * @param configuration the configuration for the feature
     */
    public static <FC extends class_3037, F extends class_3031<FC>> void registerConfiguredFeature(class_7891<class_2975<?, ?>> context,
                                                                                                   class_5321<class_2975<?, ?>> key,
                                                                                                   F feature, FC configuration)
    {
        context.method_46838(key, new class_2975<>(feature, configuration));
    }

    /**
     * Creates a list of placement modifiers with the given count and height modifier.
     *
     * @param countModifier   the count placement modifier
     * @param heightModifier  the height placement modifier
     * @return a list of placement modifiers
     */
    public static List<class_6797> modifiers(class_6797 countModifier, class_6797 heightModifier)
    {
        return List.of(countModifier, class_5450.method_39639(), heightModifier, class_6792.method_39614());
    }

    /**
     * Creates a list of placement modifiers with the given count and height modifier.
     *
     * @param count           the number of times to place the feature
     * @param heightModifier  the height placement modifier
     * @return a list of placement modifiers
     */
    public static List<class_6797> modifiersWithCount(int count, class_6797 heightModifier)
    {
        return modifiers(class_6793.method_39623(count), heightModifier);
    }

    /**
     * Creates a list of placement modifiers with the given rarity and height modifier.
     *
     * @param chance          the rarity chance
     * @param heightModifier  the height placement modifier
     * @return a list of placement modifiers
     */
    public static List<class_6797> modifiersWithRarity(int chance, class_6797 heightModifier)
    {
        return modifiers(class_6799.method_39659(chance), heightModifier);
    }
}