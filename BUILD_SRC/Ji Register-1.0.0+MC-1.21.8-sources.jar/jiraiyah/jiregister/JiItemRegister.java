/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiregister;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.utils.BaseHelper;
import jiraiyah.jiregister.factory.IToolFactory;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_2378;
import net.minecraft.class_4174;
import net.minecraft.class_5321;
import net.minecraft.class_7923;
import net.minecraft.class_7924;
import net.minecraft.class_8051;
import net.minecraft.class_9886;
import java.util.function.Function;

/**
 * Registers custom items for Minecraft.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class JiItemRegister
{
    /**
     * The mod ID used for registering items.
     */
    private final String modId;

    /**
     * Constructs a new instance of JiItemRegister with the specified mod ID.
     *
     * @param mod_ID the mod ID
     */
    public JiItemRegister(String mod_ID)
    {
        this.modId = mod_ID;
    }

    /**
     * Registers an item using default settings and a factory function.
     *
     * @param name    the name of the item
     * @return the registered item
     */
    public class_1792 register(String name)
    {
        return register(name, class_1792::new);
    }

    /**
     * Registers an item with custom settings and a factory function.
     *
     * @param name    the name of the item
     * @param settings the custom settings for the item
     * @return the registered item
     */
    public class_1792 register(String name, class_1792.class_1793 settings)
    {
        return register(name, settings, class_1792::new);
    }

    /**
     * Registers an item with a stack count and default settings using a factory function.
     *
     * @param name      the name of the item
     * @param stackCount the maximum stack size for the item
     * @return the registered item
     */
    public class_1792 register(String name, int stackCount)
    {
        return register(name, stackCount, class_1792::new);
    }

    /**
     * Registers an item with a stack count and custom settings using a factory function.
     *
     * @param name      the name of the item
     * @param stackCount the maximum stack size for the item
     * @param settings  the custom settings for the item
     * @return the registered item
     */
    public class_1792 register(String name, int stackCount, class_1792.class_1793 settings)
    {
        return register(name, stackCount, settings, class_1792::new);
    }

    /**
     * Registers an item using a factory function.
     *
     * @param <R>             the type of the item
     * @param name            the name of the item
     * @param factory         the factory used to create instances of the item
     * @return the registered item
     */
    public <R extends class_1792> R register(String name, Function<class_1792.class_1793, R> factory)
    {
        class_5321<class_1792> key = BaseHelper.getKey(this.modId, name, class_7924.field_41197);
        R item = factory.apply(new class_1792.class_1793().method_63686(key));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    /**
     * Registers an item with a stack count using a factory function.
     *
     * @param <R>             the type of the item
     * @param name            the name of the item
     * @param stackCount      the maximum stack size for the item
     * @param factory         the factory used to create instances of the item
     * @return the registered item
     */
    public <R extends class_1792> R register(String name, int stackCount, Function<class_1792.class_1793, R> factory)
    {
        class_5321<class_1792> key = BaseHelper.getKey(this.modId, name, class_7924.field_41197);
        R item = factory.apply(new class_1792.class_1793().method_63686(key). method_7889(stackCount));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    /**
     * Registers an item with custom settings using a factory function.
     *
     * @param <R>             the type of the item
     * @param name            the name of the item
     * @param settings        the custom settings for the item
     * @param factory         the factory used to create instances of the item
     * @return the registered item
     */
    public <R extends class_1792> R register(String name, class_1792.class_1793 settings, Function<class_1792.class_1793, R> factory)
    {
        class_5321<class_1792> key = BaseHelper.getKey(this.modId, name, class_7924.field_41197);
        R item = factory.apply(settings.method_63686(key));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    /**
     * Registers an item with a stack count and custom settings using a factory function.
     *
     * @param <R>             the type of the item
     * @param name            the name of the item
     * @param stackCount      the maximum stack size for the item
     * @param settings        the custom settings for the item
     * @param factory         the factory used to create instances of the item
     * @return the registered item
     */
    public <R extends class_1792> R register(String name, int stackCount, class_1792.class_1793 settings, Function<class_1792.class_1793, R> factory)
    {
        class_5321<class_1792> key = BaseHelper.getKey(this.modId, name, class_7924.field_41197);
        R item = factory.apply(settings.method_63686(key). method_7889(stackCount));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    /**
     * Registers an axe with default settings and a material.
     *
     * @param name            the name of the axe
     * @param material        the tool material for the axe
     * @param attackDamage    the attack damage of the axe
     * @param attackSpeed     the attack speed of the axe
     * @return the registered axe item
     */
    public class_1792 registerAxe(String name, class_9886 material, float attackDamage, float attackSpeed)
    {
        return register(name, new class_1792.class_1793().method_67190(material, attackDamage, attackSpeed), class_1792::new);
    }

    /**
     * Registers a hoe with default settings and a material.
     *
     * @param name            the name of the hoe
     * @param material        the tool material for the hoe
     * @param attackDamage    the attack damage of the hoe
     * @param attackSpeed     the attack speed of the hoe
     * @return the registered hoe item
     */
    public class_1792 registerHoe(String name, class_9886 material, float attackDamage, float attackSpeed)
    {
        return register(name, new class_1792.class_1793().method_67192(material, attackDamage, attackSpeed), class_1792::new);
    }

    /**
     * Registers a pickaxe with default settings and a material.
     *
     * @param name            the name of the pickaxe
     * @param material        the tool material for the pickaxe
     * @param attackDamage    the attack damage of the pickaxe
     * @param attackSpeed     the attack speed of the pickaxe
     * @return the registered pickaxe item
     */
    public class_1792 registerPickaxe(String name, class_9886 material, float attackDamage, float attackSpeed)
    {
        return register(name, new class_1792.class_1793().method_66330(material, attackDamage, attackSpeed), class_1792::new);
    }

    /**
     * Registers a shovel with default settings and a material.
     *
     * @param name            the name of the shovel
     * @param material        the tool material for the shovel
     * @param attackDamage    the attack damage of the shovel
     * @param attackSpeed     the attack speed of the shovel
     * @return the registered shovel item
     */
    public class_1792 registerShovel(String name, class_9886 material, float attackDamage, float attackSpeed)
    {
        return register(name, new class_1792.class_1793().method_67193(material, attackDamage, attackSpeed), class_1792::new);
    }

    /**
     * Registers a sword with default settings and a material.
     *
     * @param name            the name of the sword
     * @param material        the tool material for the sword
     * @param attackDamage    the attack damage of the sword
     * @param attackSpeed     the attack speed of the sword
     * @return the registered sword item
     */
    public class_1792 registerSword(String name, class_9886 material, float attackDamage, float attackSpeed)
    {
        return register(name, new class_1792.class_1793().method_66333(material, attackDamage, attackSpeed), class_1792::new);
    }

    /**
     * Registers a tool with default settings and a material.
     *
     * @param <R>             the type of the tool item
     * @param name            the name of the tool item
     * @param material        the tool material for the tool
     * @param attackDamage    the attack damage of the tool
     * @param attackSpeed     the attack speed of the tool
     * @param factory         the factory used to create instances of the tool item
     * @return the registered tool item
     */
    public <R extends class_1792> R registerTool(String name, class_9886 material, float attackDamage, float attackSpeed,
                                           IToolFactory<class_1792.class_1793, R> factory)
    {
        class_5321<class_1792> key = BaseHelper.getKey(this.modId, name, class_7924.field_41197);
        R item = factory.apply(material, attackDamage, attackSpeed, new class_1792.class_1793().method_63686(key));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    /**
     * Registers a tool with custom settings and a material.
     *
     * @param <R>             the type of the tool item
     * @param name            the name of the tool item
     * @param material        the tool material for the tool
     * @param attackDamage    the attack damage of the tool
     * @param attackSpeed     the attack speed of the tool
     * @param settings        the custom settings for the tool item
     * @param factory         the factory used to create instances of the tool item
     * @return the registered tool item
     */
    public <R extends class_1792> R registerTool(String name, class_9886 material, float attackDamage, float attackSpeed,
                                           class_1792.class_1793 settings, IToolFactory<class_1792.class_1793, R> factory)
    {
        class_5321<class_1792> key = BaseHelper.getKey(this.modId, name, class_7924.field_41197);
        R item = factory.apply(material, attackDamage, attackSpeed, settings.method_63686(key));
        return class_2378.method_39197(class_7923.field_41178, key, item);
    }

    /**
     * Registers an armor item with default settings and a material.
     *
     * @param name            the name of the armor item
     * @param material        the armor material for the armor item
     * @param equipment   the type of armor (e.g., helmet, chestplate)
     * @return the registered armor item
     */
    public class_1792 registerArmor(String name, class_1741 material, class_8051 equipment)
    {
        return register(name, new class_1792.class_1793().method_66332(material, equipment), class_1792::new);
    }

    /**
     * Registers an armor item with custom settings and a material.
     *
     * @param name            the name of the armor item
     * @param material        the armor material for the armor item
     * @param equipment   the type of armor (e.g., helmet, chestplate)
     * @param settings        the custom settings for the armor item
     * @return the registered armor item
     */
    public class_1792 registerArmor(String name, class_1741 material, class_8051 equipment, class_1792.class_1793 settings)
    {
        return register(name, settings.method_66332(material, equipment), class_1792::new);
    }

    /**
     * Registers a snack food item with default settings.
     *
     * @param name            the name of the food item
     * @param stackCount      the maximum stack size for the food item
     * @param nutrition       the nutritional value of the food item
     * @param saturation      the saturation modifier of the food item
     * @return the registered snack food item
     */
    public class_1792 registerSnackFood(String name, int stackCount, int nutrition, float saturation)
    {
        return register(name, stackCount,
                        new class_1792.class_1793()
                                            .method_19265(new class_4174.class_4175()
                                                          .method_19238(nutrition)
                                                          .method_19237(saturation)
                                                          .method_19240()
                                                          .method_19242()));
    }

    /**
     * Registers a food item with default settings.
     *
     * @param name            the name of the food item
     * @param stackCount      the maximum stack size for the food item
     * @param nutrition       the nutritional value of the food item
     * @param saturation      the saturation modifier of the food item
     * @return the registered food item
     */
    public class_1792 registerFood(String name, int stackCount, int nutrition, float saturation)
    {
        return register(name, stackCount,
                        new class_1792.class_1793()
                                .method_19265(new class_4174.class_4175()
                                              .method_19238(nutrition)
                                              .method_19237(saturation)
                                              .method_19242()));
    }
}