/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiregister.mixin;

import jiraiyah.jiregister.interfaces.BlockStateModelGeneratorAccessor;
import net.minecraft.class_10804;
import net.minecraft.class_4910;
import net.minecraft.class_4926;
import org.spongepowered.asm.mixin.Mixin;
import org.spongepowered.asm.mixin.Shadow;

/**
 * Mixin implementation of BlockStateModelGeneratorAccessor interface.
 */
@Mixin(class_4910.class)
public class BlockStateModelGeneratorMixin implements BlockStateModelGeneratorAccessor
{
    /**
     * The static field representing the default horizontal rotation operations for the north-facing variant.
     */
    @Shadow
    private static class_4926<class_10804> NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS;

    /**
     * Retrieves the default horizontal rotation operations for the north-facing variant of a block.
     *
     * @return The block state variant map containing operations for the north-facing variant.
     */
    @Override
    public class_4926<class_10804> getNorthDefaultHorizontalRotationOperations()
    {
        return NORTH_DEFAULT_HORIZONTAL_ROTATION_OPERATIONS;
    }
}