/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiregister;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.utils.BaseHelper;
import net.minecraft.class_10186;
import net.minecraft.class_10191;
import net.minecraft.class_10192;
import net.minecraft.class_10394;
import net.minecraft.class_1304;
import net.minecraft.class_156;
import net.minecraft.class_1741;
import net.minecraft.class_1792;
import net.minecraft.class_2960;
import net.minecraft.class_3414;
import net.minecraft.class_4915;
import net.minecraft.class_5321;
import net.minecraft.class_6862;
import net.minecraft.class_6880;
import net.minecraft.class_7923;
import net.minecraft.class_8051;
import net.minecraft.class_9334;
import net.minecraft.class_9336;
import java.util.EnumMap;
import java.util.HashMap;
import java.util.Map;

/**
 * Provides utility methods for managing armor-related data.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class ArmorHelper
{
    /**
     * Maps equipment slots to their corresponding armor model names.
     */
    public static Map<String, class_2960> SlotToArmorNames = new HashMap<>();

    static
    {
        SlotToArmorNames.put(class_1304.field_6169.method_5923(), class_4915.field_56347);
        SlotToArmorNames.put(class_1304.field_6174.method_5923(), class_4915.field_56348);
        SlotToArmorNames.put(class_1304.field_6172.method_5923(), class_4915.field_56349);
        SlotToArmorNames.put(class_1304.field_6166.method_5923(), class_4915.field_56350);
        SlotToArmorNames.put(class_1304.field_48824.method_5923(), class_4915.method_67260(class_1304.field_48824.method_5923()));
    }

    /**
     * Creates a new armor material with the specified properties.
     *
     * @param modID               The unique identifier for the mod.
     * @param name                The name of the armor material.
     * @param durability          The durability of the armor material.
     * @param bootDefence         The defence value for boots.
     * @param leggingsDefence     The defence value for leggings.
     * @param chestplateDefence   The defence value for chestplates.
     * @param helmetDefence       The defence value for helmets.
     * @param bodyDefence         The defence value for body armor.
     * @param enchantmentValue    The enchantment value of the armor material.
     * @param equipSound          The sound event to play when equipping the armor.
     * @param toughness           The toughness value of the armor material.
     * @param knockbackResistance The knockback resistance value of the armor material.
     * @param repairIngredient    The tag key for repairing ingredients.
     * @return A new ArmorMaterial instance.
     */
    public static class_1741 getArmorMaterial(String modID, String name, int durability, int bootDefence, int leggingsDefence, int chestplateDefence, int helmetDefence,
                                                 int bodyDefence, int enchantmentValue, class_6880<class_3414> equipSound, float toughness,
                                                 float knockbackResistance, class_6862<class_1792> repairIngredient)
    {
        class_5321<class_10394> key = class_5321.method_29179(class_10191.field_55214, BaseHelper.identifier(modID, name));
        return new class_1741(durability,
                                 class_156.method_654(new EnumMap<>(class_8051.class),
                                            (map) ->
                                                           {
                                                               map.put(class_8051.field_41937, bootDefence);
                                                               map.put(class_8051.field_41936, leggingsDefence);
                                                               map.put(class_8051.field_41935, chestplateDefence);
                                                               map.put(class_8051.field_41934, helmetDefence);
                                                               map.put(class_8051.field_48838, bodyDefence);
                                                           }),
                                 enchantmentValue, equipSound,
                                 toughness, knockbackResistance, repairIngredient,
                                 key);
    }

    /**
     * Generates all armor models for the specified armors.
     *
     * @param modID The unique identifier for the mod.
     * @param generator The ItemModelGenerator instance for generating models.
     * @param armors An array of armor items to generate models for.
     */
    public static void generateAllArmorModels(String modID, class_4915 generator, class_1792[] armors)
    {
        class_8051 slot;

        for (class_1792 armor : armors)
            generateArmorModel(modID, generator, armor);
    }

    /**
     * Generates an armor model for the specified armor item.
     *
     * @param modID The unique identifier for the mod.
     * @param generator The ItemModelGenerator instance for generating models.
     * @param armor The armor item to generate a model for.
     */
    public static void generateArmorModel(String modID, class_4915 generator, class_1792 armor)
    {
        generateArmorModel(modID, generator, armor, false);
    }

    /**
     * Generates an armor model for the specified armor item with an option to mark it as dyeable.
     *
     * @param modID The unique identifier for the mod.
     * @param generator The ItemModelGenerator instance for generating models.
     * @param armor The armor item to generate a model for.
     * @param dyeable Whether the armor model should be marked as dyeable.
     */
    public static void generateArmorModel(String modID, class_4915 generator, class_1792 armor, boolean dyeable)
    {
        class_9336<class_10192> component = armor.method_57347().method_66876(class_9334.field_54196);
        if (component == null)
            throw new IllegalArgumentException("The item " + armor.method_63680() + " does not have equippable component");
        class_2960 TrimID = SlotToArmorNames.get(component.comp_2444().comp_3174().method_5923());
        String name = class_7923.field_41178.method_10221(armor).method_12832();
        class_5321<class_10394> key = class_5321.method_29179(class_10191.field_55214, BaseHelper.identifier(modID, name));
        generator.method_65429(armor, key, TrimID, dyeable);
    }

    /**
     * Builds an EquipmentModel for a humanoid entity.
     *
     * @param modID The unique identifier for the mod.
     * @param name The name of the model.
     * @return An EquipmentModel instance with humanoid layers.
     */
    public static class_10186 buildHumanoid(String modID, String name)
    {
        return class_10186.method_63994().method_63998(BaseHelper.identifier(modID, name)).method_63997();
    }

    /**
     * Builds an EquipmentModel for a humanoid and horse entity.
     *
     * @param modID The unique identifier for the mod.
     * @param name The name of the model.
     * @return An EquipmentModel instance with humanoid and horse layers.
     */
    public static class_10186 buildHumanoidAndHorse(String modID, String name)
    {
        return class_10186.method_63994()
                             .method_63998(BaseHelper.identifier(modID, name))
                .method_64001(class_10186.class_10190.field_54129,
                           class_10186.class_10189.method_64005(BaseHelper.identifier(modID, name), false))
                             .method_63997();
    }
}