/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiregister;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.exceptions.Exceptions;
import jiraiyah.jiregister.interfaces.BlockStateModelGeneratorAccessor;
import net.minecraft.class_2248;
import net.minecraft.class_2746;
import net.minecraft.class_2960;
import net.minecraft.class_4910;
import net.minecraft.class_4925;
import net.minecraft.class_4926;
import net.minecraft.class_4943;
import net.minecraft.class_4944;
import net.minecraft.class_4945;
import net.minecraft.class_4946;
import net.minecraft.class_807;
import net.minecraft.client.data.*;

/**
 * Provides utility methods for generating block state models.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class ModelHelper
{
    /**
     * Private constructor to prevent instantiation.
     */
    public ModelHelper()
    {
        Exceptions.throwCtorAssertion();
    }

    // look into registerCooker from BlockStateModelGenerator
    // look into register() from BlockStateModelGenerator and it's Furnace registration

    /**
     * Registers an orientable variant block with boolean property.
     *
     * @param generator the block state model generator
     * @param block       the block to register
     * @param property    the boolean property used for determining the model state
     */
    public static void registerOrientableVariantBlock(class_4910 generator, class_2248 block, class_2746 property)
    {
        class_807 blockOFF = class_4910.method_67835(class_4946.field_23042.method_25923(block, generator.field_22831));
        class_2960 blockFront = class_4944.method_25866(block, "_front_on");
        class_807 blockON = class_4910.method_67835(class_4946.field_23042.get(block)
                                                                                                      .method_25917(textureMap ->
                                                                                                                        textureMap.method_25868(class_4945.field_23016, blockFront))
                                                                                                      .method_25915(block, "_on", generator.field_22831));
        generator.field_22830.accept(class_4925.method_67852(block)
                                                        .method_67859(class_4910.method_25565(property, blockON, blockOFF))
                                                                                .method_25775(((BlockStateModelGeneratorAccessor) generator).getNorthDefaultHorizontalRotationOperations()));
    }

    /**
     * Registers a cube variant block with boolean property.
     *
     * @param generator the block state model generator
     * @param block       the block to register
     * @param property    the boolean property used for determining the model state
     */
    @ThanksTo(discordUsers = "Waveless")
    public static void registerCubeVariantBlock(class_4910 generator, class_2248 block, class_2746 property)
    {
        class_807 cubeOff = class_4910.method_67835(class_4946.field_23036.method_25923(block, generator.field_22831));
        class_807 cubeOn = class_4910.method_67835((generator.method_25557(block, "_on", class_4943.field_22972, class_4944::method_25875)));
        class_4926<class_807> cubeStatus = class_4910.method_25565(property, cubeOn, cubeOff);
        generator.field_22830.accept(class_4925.method_67852(block)
                                                                                .method_67859(cubeStatus));
    }
}