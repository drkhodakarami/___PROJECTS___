/***********************************************************************************
 * Copyright (c) 2025 Alireza Khodakarami (Jiraiyah)                               *
 * ------------------------------------------------------------------------------- *
 * MIT License                                                                     *
 * =============================================================================== *
 * Permission is hereby granted, free of charge, to any person obtaining a copy    *
 * of this software and associated documentation files (the "Software"), to deal   *
 * in the Software without restriction, including without limitation the rights    *
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell       *
 * copies of the Software, and to permit persons to whom the Software is           *
 * furnished to do so, subject to the following conditions:                        *
 * ------------------------------------------------------------------------------- *
 * The above copyright notice and this permission notice shall be included in all  *
 * copies or substantial portions of the Software.                                 *
 * ------------------------------------------------------------------------------- *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR      *
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,        *
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE     *
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER          *
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,   *
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN THE   *
 * SOFTWARE.                                                                       *
 ***********************************************************************************/

package jiraiyah.jiregister;

import jiraiyah.jibase.annotations.*;
import jiraiyah.jibase.exceptions.Exceptions;
import net.fabricmc.fabric.api.datagen.v1.provider.FabricBlockLootTableProvider;
import net.minecraft.class_141;
import net.minecraft.class_1792;
import net.minecraft.class_1887;
import net.minecraft.class_1893;
import net.minecraft.class_2248;
import net.minecraft.class_52;
import net.minecraft.class_5662;
import net.minecraft.class_7225;
import net.minecraft.class_77;
import net.minecraft.class_7924;
import net.minecraft.class_94;

/**
 * Provides utility methods for generating loot tables.
 */
@SuppressWarnings("unused")
@Developer("Jiraiyah")
@CreatedAt("2025-04-18")
@Repository("https://github.com/drkhodakarami/___PROJECTS___")
@Discord("https://discord.gg/pmM4emCbuH")
@Youtube("https://www.youtube.com/@TheMentorCodeLab")

public class LootTableHelper
{
    /**
     * Private constructor to prevent instantiation.
     */
    public LootTableHelper()
    {
        Exceptions.throwCtorAssertion();
    }

    /**
     * Generates a loot table entry for an ore block with random item drops and fortune enchantment.
     *
     * @param provider      the block loot table provider
     * @param registries    the registry wrapper lookup
     * @param block         the ore block
     * @param item          the item dropped by the ore
     * @param min           the minimum number of items to drop
     * @param max           the maximum number of items to drop
     * @return a loot table builder with the specified drops and enchantments
     */
    public static class_52.class_53 addOreDrops(FabricBlockLootTableProvider provider, class_7225.class_7874 registries,
                                                class_2248 block, class_1792 item, float min, float max)
    {
        class_7225.class_7226<class_1887> impl = registries.method_46762(class_7924.field_41265);
        return provider.method_45989(block,
                                           (class_77.method_411(item)
                                                       .method_438(class_141
                                                                  .method_621(class_5662.method_32462(min, max))))
                                                       .method_438(class_94
                                                                  .method_455(impl.method_46747(class_1893.field_9130))));
    }


    /**
     * Generates a loot table entry for an ore block with random item drops and a default range (2.0f to 5.0f).
     *
     * @param provider      the block loot table provider
     * @param registries    the registry wrapper lookup
     * @param block         the ore block
     * @param item          the item dropped by the ore
     * @return a loot table builder with the specified drops and enchantments
     */
    public static class_52.class_53 addOreDrops(FabricBlockLootTableProvider provider, class_7225.class_7874 registries,
                                                class_2248 block, class_1792 item)
    {
        return addOreDrops(provider, registries, block, item, 2.0f, 5.0f);
    }
}